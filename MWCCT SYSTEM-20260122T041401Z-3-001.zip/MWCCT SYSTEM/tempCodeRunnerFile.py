def open_signup(self):
        self.core.destroy()
        SignUp()