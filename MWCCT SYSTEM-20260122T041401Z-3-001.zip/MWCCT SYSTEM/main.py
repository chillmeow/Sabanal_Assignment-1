from tkinter import *
from PIL import Image, ImageTk
import os

# Main Window
class MainWindow:
    def __init__(self, core):
        self.core = core
        self.core.title("MWCCT SYSTEM")
        self.core.geometry("1100x700+400+50")
        self.core.configure(bg="white")

        icon_path = os.path.join("Assets", "logo (2).png")
        icon = PhotoImage(file=icon_path)
        self.core.iconphoto(True, icon)

        frame = Frame(self.core, bg="white", width=1000, height=700)
        frame.pack(pady=40)

        logo_path = os.path.join("Assets", "logo (2).png")
        logo_image = Image.open(logo_path)
        logo_image = logo_image.resize((200, 200))
        self.logo_photo = ImageTk.PhotoImage(logo_image)
        logo_label = Label(frame, image=self.logo_photo, bg="white")
        logo_label.pack(pady=(20, 10))

        title = Label(frame,
                      text="Welcome to",
                      font=("DM Sans", 34, "bold"),
                      bg="white",
                      fg="black")
        title.pack(pady=(5, 10))

        SubTitle = Label(frame,
                         text="Municipality of Villanueva\nWaste Collection\n& Complaints\nTracker System",
                         font=("DM Sans", 20, "bold"), bg="white", fg="black", justify="center")
        SubTitle.pack(pady=(0, 30))

        GSbutton = Button(frame, text="GET STARTED",
                          font=("Arial", 12, "bold"),
                          bg="white",
                          fg="black",
                          relief="raised",
                          borderwidth=1,
                          cursor="hand2",
                          activebackground="black",
                          activeforeground="white",
                          command=self.open_login_window)
        GSbutton.pack(pady=(0, 10))

    def open_login_window(self):
        self.core.destroy()
        Login()


# Login Window
class Login:
    def __init__(self):
        self.core = Tk()
        self.core.title("MWCCT SYSTEM")
        self.core.geometry("1100x700+400+50")

        image_path = os.path.join("Assets", "VILLANUEVA WASTE.png")
        image = Image.open(image_path)
        image = image.resize((1100, 700))
        self.photo = ImageTk.PhotoImage(image)
        label = Label(self.core, image=self.photo)
        label.pack()

        Lframe = Frame(self.core,
                       bg="#05a831",
                       width=400,
                       height=400,
                       bd=5,
                       relief="raised")
        Lframe.place(x=659, y=130)
        Lframe.pack_propagate(False)

        login = Label(Lframe,
                      text="LOGIN TO YOUR\nACCOUNT",
                      font=("DM Sans", 20, "bold"),
                      fg="#080154",
                      bg="#05a831")
        login.pack(pady=(10, 20))

        username_label = Label(Lframe, text="Username :", font=("Arial", 12), bg="#05a831")
        username_label.place(x=35, y=100)
        username_entry_box = Frame(Lframe, bg="white")
        username_entry_box.place(x=35, y=130, width=320, height=34)
        username_entry = Entry(username_entry_box, font=("Arial", 12), borderwidth=0, relief="flat")
        username_entry.pack(fill="both", expand=True, padx=10)

        email_label = Label(Lframe, text="Email Address :", font=("Arial", 12), bg="#05a831")
        email_label.place(x=35, y=170)
        email_entry_box = Frame(Lframe, bg="white")
        email_entry_box.place(x=35, y=200, width=320, height=34)
        email_entry = Entry(email_entry_box, font=("Arial", 12), borderwidth=0, relief="flat")
        email_entry.pack(fill="both", expand=True, padx=10)

        password_label = Label(Lframe, text="Password :", font=("Arial", 12), bg="#05a831")
        password_label.place(x=35, y=240)
        password_entry_box = Frame(Lframe, bg="white")
        password_entry_box.place(x=35, y=270, width=320, height=34)
        self.password_entry = Entry(password_entry_box, font=("Arial", 12), borderwidth=0, relief="flat")
        self.password_entry.pack(fill="both", expand=True, padx=10)

        username_entry.bind("<Return>", lambda event: email_entry.focus_set())
        email_entry.bind("<Return>", lambda event: self.password_entry.focus_set())
        self.password_entry.bind("<Return>", lambda event: self.login())

        eye_open = Image.open(os.path.join("Assets", "eye open.png"))
        eye_open = eye_open.resize((20, 20))
        self.eye_open_img = ImageTk.PhotoImage(eye_open)

        eye_close = Image.open(os.path.join("Assets", "eye close.png"))
        eye_close = eye_close.resize((20, 20))
        self.eye_close_img = ImageTk.PhotoImage(eye_close)

        self.toggle_button = Button(Lframe,
                                    image=self.eye_close_img,
                                    bg="white",
                                    relief="flat",
                                    bd=0,
                                    command=self.toggle_password)
        self.toggle_button.place(x=320, y=274, width=30, height=25)

        self.show_password = False

        # Clickable Sign Up label
        self.signup_label = Label(self.core, text="Don't have an account?\n Sign Up now",
                                  font=("Arial", 10), background="#17224d", fg="white", cursor="hand2")
        self.signup_label.place(x=675, y=560)
        self.signup_label.bind("<Button-1>", lambda event: self.open_signup())

        Lbutton = Button(self.core,
                         text="LOGIN",
                         font=("DM Sans", 15, "bold"),
                         bg="white",
                         fg="#17224d",
                         width=10,
                         height=0,
                         relief="raised",
                         cursor="hand2")
        Lbutton.place(x=900, y=560)

        self.core.mainloop()

    def toggle_password(self):
        if self.show_password:
            self.password_entry.config(show="*")
            self.toggle_button.config(image=self.eye_close_img)
        else:
            self.password_entry.config(show="")
            self.toggle_button.config(image=self.eye_open_img)
        self.show_password = not self.show_password

    def open_signup(self):
        self.core.destroy()
        SignUp()

    def login(self):
        print("Login logic goes here.")


# SignUp Window
class SignUp:
    def __init__(self):
        self.core = Tk()
        self.core.title("Sign Up - MWCCT SYSTEM")
        self.core.geometry("600x400+500+200")
        self.core.configure(bg="white")

        Label(self.core,
              text="Sign Up Page (Under Construction)",
              font=("Arial", 18, "bold"),
              bg="white",
              fg="black").pack(pady=150)

        Button(self.core, text="Back to Login", command=self.back_to_login).pack()

        self.core.mainloop()

    def back_to_login(self):
        self.core.destroy()
        Login()


if __name__ == "__main__":
    core = Tk()
    window = MainWindow(core)
    core.mainloop()
