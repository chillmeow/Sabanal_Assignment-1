# accounting.py
# JSON-based accounting core used by main.py

import json, os
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


def _ensure_data_dir():
    """Make sure the data directory exists."""
    os.makedirs(DATA_DIR, exist_ok=True)


def read_coa():
    """
    Read chart of accounts from JSON.

    Expected format (chart_of_accounts.json):
    {
      "accounts": [
        { "number": 101, "name": "Cash", "group": "Asset" },
        ...
      ]
    }
    """
    coa = {}
    p = os.path.join(DATA_DIR, "chart_of_accounts.json")
    if not os.path.exists(p):
        return coa
    with open(p, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            return coa
    for acc in data.get("accounts", []):
        code = str(acc.get("number", "")).strip()
        name = acc.get("name", "").strip()
        group = acc.get("group", "").strip()
        if not code or not name:
            continue

        # Map JSON "group" to internal types
        group_lower = group.lower()
        if group_lower == "asset":
            a_type = "Asset"
        elif group_lower == "liability":
            a_type = "Liability"
        elif group_lower in ["equity", "capital"]:
            a_type = "Equity"
        elif group_lower in ["income", "revenue"]:
            a_type = "Revenue"
        elif group_lower in ["expense", "expenses"]:
            a_type = "Expense"
        else:
            # Fallback to group text, but capitalise first letter
            a_type = group.capitalize() if group else "Other"

        coa[code] = {"name": name, "type": a_type}
    return coa


def read_transactions():
    """
    Read transactions from JSON list.
    transactions.json is expected to be a JSON array (possibly empty).
    """
    p = os.path.join(DATA_DIR, "transactions.json")
    if not os.path.exists(p):
        return []
    with open(p, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            return []
    # Normalise to list of dicts
    return [row for row in data if isinstance(row, dict) and row.get("id")]


def add_transaction(tx):
    """
    Append a transaction to transactions.json.
    """
    _ensure_data_dir()
    p = os.path.join(DATA_DIR, "transactions.json")
    rows = []
    if os.path.exists(p) and os.path.getsize(p) > 0:
        with open(p, "r", encoding="utf-8") as f:
            try:
                rows = json.load(f)
            except json.JSONDecodeError:
                rows = []
    if not isinstance(rows, list):
        rows = []
    rows.append({
        "id": tx["id"],
        "date": tx["date"],
        "description": tx["description"],
        "debit_account_code": str(tx["debit_account_code"]),
        "credit_account_code": str(tx["credit_account_code"]),
        "amount": float(tx["amount"]),
        "posted": tx.get("posted", "yes"),
    })
    with open(p, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)


def read_journal():
    """
    Read journal entries from journal.json.

    Expected format: a JSON array of entries with keys:
    - journal_id
    - date
    - description
    - debit_account_code
    - debit_amount
    - credit_account_code
    - credit_amount
    """
    p = os.path.join(DATA_DIR, "journal.json")
    if not os.path.exists(p):
        return []
    with open(p, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            return []
    return [row for row in data if isinstance(row, dict) and row.get("journal_id")]


def add_journal_entry(entry):
    """
    Append a journal entry to journal.json.
    """
    _ensure_data_dir()
    p = os.path.join(DATA_DIR, "journal.json")
    rows = []
    if os.path.exists(p) and os.path.getsize(p) > 0:
        with open(p, "r", encoding="utf-8") as f:
            try:
                rows = json.load(f)
            except json.JSONDecodeError:
                rows = []
    if not isinstance(rows, list):
        rows = []
    rows.append({
        "journal_id": entry["journal_id"],
        "date": entry["date"],
        "description": entry["description"],
        "debit_account_code": str(entry["debit_account_code"]),
        "debit_amount": float(entry["debit_amount"]),
        "credit_account_code": str(entry["credit_account_code"]),
        "credit_amount": float(entry["credit_amount"]),
    })
    with open(p, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)

def rebuild_ledger_from_journal():
    """
    LEGACY HELPER (JSON-BASED) – kept for compatibility but no longer used
    by the UI. See _rebuild_balances_from_db() for the live SQLite-backed
    implementation.
    """
    coa = read_coa()
    accounts = {}
    for code, info in coa.items():
        accounts[code] = {
            "name": info["name"],
            "debit": 0.0,
            "credit": 0.0,
            "type": info["type"],
        }

    for j in read_journal():
        # Use explicit debit and credit amounts from journal
        try:
            debit_amt = float(j.get("debit_amount", 0) or 0)
        except (TypeError, ValueError):
            debit_amt = 0.0
        try:
            credit_amt = float(j.get("credit_amount", 0) or 0)
        except (TypeError, ValueError):
            credit_amt = 0.0

        da = str(j.get("debit_account_code", "")).strip()
        ca = str(j.get("credit_account_code", "")).strip()
        if da in accounts:
            accounts[da]["debit"] += debit_amt
        if ca in accounts:
            accounts[ca]["credit"] += credit_amt

    balances = {}
    for code, vals in accounts.items():
        a_type = vals["type"]
        if a_type in ["Asset", "Expense", "Expenses"]:
            bal = vals["debit"] - vals["credit"]
        else:
            bal = vals["credit"] - vals["debit"]
        balances[code] = {
            "name": vals["name"],
            "debit": round(vals["debit"], 2),
            "credit": round(vals["credit"], 2),
            "balance": round(bal, 2),
            "type": a_type,
        }
    return balances


def _rebuild_balances_from_db():
    """
    Core balance builder used by trial balance and financial statements.

    Uses the live SQLite data (chart_of_accounts + posted transactions),
    so every page is driven from the same source of truth.
    """
    # Local import to avoid any accidental circulars at import time.
    from db import get_all_accounts, get_posted_transactions

    coa_rows = get_all_accounts()
    txs = get_posted_transactions()

    accounts = {}
    for a in coa_rows:
        code = str(a.get("number", "")).strip()
        name = str(a.get("name", "")).strip()
        group = str(a.get("group", "")).strip()
        if not code or not name:
            continue

        g_lower = group.lower()
        if g_lower == "asset":
            a_type = "Asset"
        elif g_lower == "liability":
            a_type = "Liability"
        elif g_lower in ("equity", "capital"):
            a_type = "Equity"
        elif g_lower in ("income", "revenue"):
            # Normal credit accounts – treated as income
            a_type = "Income"
        elif g_lower in ("expense", "expenses"):
            # Normal debit accounts – treated as expenses
            a_type = "Expenses"
        else:
            a_type = group.capitalize() if group else "Other"

        accounts[code] = {
            "name": name,
            "debit": 0.0,
            "credit": 0.0,
            "type": a_type,
        }

    for t in txs:
        da_code = str(t.get("debit_acc_code", "")).strip()
        ca_code = str(t.get("credit_acc_code", "")).strip()
        try:
            debit_amt = float(t.get("debit_amt", 0) or 0)
        except (TypeError, ValueError):
            debit_amt = 0.0
        try:
            credit_amt = float(t.get("credit_amt", 0) or 0)
        except (TypeError, ValueError):
            credit_amt = 0.0

        if da_code in accounts:
            accounts[da_code]["debit"] += debit_amt
        if ca_code in accounts:
            accounts[ca_code]["credit"] += credit_amt

    balances = {}
    for code, vals in accounts.items():
        a_type = vals["type"]
        if a_type in ["Asset", "Expenses"]:
            bal = vals["debit"] - vals["credit"]
        else:
            bal = vals["credit"] - vals["debit"]
        balances[code] = {
            "name": vals["name"],
            "debit": round(vals["debit"], 2),
            "credit": round(vals["credit"], 2),
            "balance": round(bal, 2),
            "type": a_type,
        }
    return balances

def unadjusted_trial_balance():
    # Use DB-backed balances so this stays in sync with the rest of the UI.
    balances = _rebuild_balances_from_db()
    rows = []
    td = tc = 0.0
    for code, info in balances.items():
        a_type = info["type"]
        bal = info["balance"]
        if a_type in ["Asset", "Expense", "Expenses"]:
            debit = bal if bal>0 else 0.0
            credit = -bal if bal<0 else 0.0
        else:
            credit = bal if bal>0 else 0.0
            debit = -bal if bal<0 else 0.0
        rows.append({"code":code,"name":info["name"],"debit":round(debit,2),"credit":round(credit,2)})
        td += debit; tc += credit
    return rows, round(td,2), round(tc,2)

def apply_adjusting_entries(adjs):
    for a in adjs:
        add_journal_entry(a)

def generate_financial_statements():
    """
    Build Income Statement, Statement of Owner's Equity, and Balance Sheet
    from the current ledger balances.

    Accounting conventions:
    - Assets & Expenses: normal debit balance = debit - credit
    - Liabilities, Equity, Revenue: normal credit balance = credit - debit
    - Drawings/Withdrawals (equity accounts whose name contains "withdraw" or "draw"):
      are treated as reductions of equity (positive amount reduces capital).
    """
    # Use live SQLite-backed balances so all pages are consistent.
    balances = _rebuild_balances_from_db()

    # Income Statement
    total_rev = 0.0
    total_exp = 0.0
    for _, info in balances.items():
        if info["type"] in ("Income", "Revenue"):
            total_rev += info["balance"]
        elif info["type"] in ("Expense", "Expenses"):
            total_exp += info["balance"]
    net_income = round(total_rev - total_exp, 2)

    # Statement of Owner's Equity
    capital = 0.0
    withdrawals = 0.0
    for _, info in balances.items():
        if info["type"] == "Equity":
            name_lower = info["name"].lower()
            bal = info["balance"]
            if ("withdraw" in name_lower) or ("drawing" in name_lower) or ("drawings" in name_lower) or ("owner's draw" in name_lower):
                # Treat as a positive reduction of equity, regardless of internal sign
                withdrawals += abs(bal)
            else:
                capital += bal

    ending_capital = round(capital + net_income - withdrawals, 2)

    # Balance Sheet groupings (keep raw signed balances for transparency)
    assets = {k: v["balance"] for k, v in balances.items() if v["type"] == "Asset"}
    liabilities = {k: v["balance"] for k, v in balances.items() if v["type"] == "Liability"}
    equity = {k: v["balance"] for k, v in balances.items() if v["type"] == "Equity"}

    return {
        "income_statement": {
            "total_revenues": round(total_rev, 2),
            "total_expenses": round(total_exp, 2),
            "net_income": net_income,
        },
        "statement_of_owner_equity": {
            "beginning_capital": round(capital, 2),
            "net_income": net_income,
            "withdrawals": round(withdrawals, 2),
            "ending_capital": ending_capital,
        },
        "balance_sheet": {
            "assets": assets,
            "liabilities": liabilities,
            "equity": equity,
        },
    }
