import calendar
from datetime import datetime

import customtkinter as ctk
import tkinter as tk


class DateEntry(ctk.CTkFrame):
    """
    A small reusable date-entry widget:
    - Shows a CTkEntry plus a calendar button.
    - Clicking the button opens a simple month-view picker.
    - Exposes get/insert/delete/configure methods similar to CTkEntry
      so existing code can keep using self.date_entry like a normal entry.
    """

    def __init__(self, master=None, width=160, placeholder_text="YYYY-MM-DD", **kwargs):
        super().__init__(master, fg_color="transparent")

        self._entry = ctk.CTkEntry(self, width=width, placeholder_text=placeholder_text, **kwargs)
        self._entry.pack(side="left", fill="x", expand=True)

        self._btn = ctk.CTkButton(
            self,
            text="📅",
            width=32,
            fg_color="#0a1a2e",
            hover_color="#003b63",
            command=self._open_picker,
        )
        self._btn.pack(side="left", padx=(4, 0))

        self._popup = None
        today = datetime.today()
        self._year = today.year
        self._month = today.month

    # --- API-compatible helpers ---
    def get(self):
        return self._entry.get()

    def delete(self, first, last=None):
        self._entry.delete(first, last)

    def insert(self, index, string):
        self._entry.insert(index, string)

    def configure(self, **kwargs):
        """Forward config such as state to the underlying entry."""
        self._entry.configure(**kwargs)
        super().configure()

    # --- Calendar logic ---
    def _open_picker(self):
        if self._popup is not None and tk.Toplevel.winfo_exists(self._popup):
            # If already open, just focus it
            self._popup.lift()
            return

        self._popup = tk.Toplevel(self)
        self._popup.transient(self.winfo_toplevel())
        self._popup.title("Select Date")
        self._popup.resizable(False, False)

        # Position near the entry widget
        x = self.winfo_rootx()
        y = self.winfo_rooty() + self.winfo_height()
        self._popup.geometry(f"+{x}+{y}")

        self._build_calendar()

    def _build_calendar(self):
        for child in self._popup.winfo_children():
            child.destroy()

        header = ctk.CTkFrame(self._popup)
        header.pack(fill="x", pady=(4, 2), padx=4)

        prev_btn = ctk.CTkButton(header, text="<", width=28, command=self._prev_month)
        prev_btn.pack(side="left")

        lbl = ctk.CTkLabel(
            header,
            text=f"{calendar.month_name[self._month]} {self._year}",
            font=("Segoe UI", 11, "bold"),
        )
        lbl.pack(side="left", expand=True)

        next_btn = ctk.CTkButton(header, text=">", width=28, command=self._next_month)
        next_btn.pack(side="right")

        body = ctk.CTkFrame(self._popup)
        body.pack(padx=4, pady=(0, 4))

        # Weekday headers
        for i, name in enumerate(["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]):
            ctk.CTkLabel(body, text=name, width=26).grid(row=0, column=i, padx=1, pady=1)

        cal = calendar.Calendar(firstweekday=0)
        row = 1
        for week in cal.monthdayscalendar(self._year, self._month):
            for col, day in enumerate(week):
                if day == 0:
                    ctk.CTkLabel(body, text="", width=26).grid(row=row, column=col, padx=1, pady=1)
                    continue
                btn = ctk.CTkButton(
                    body,
                    text=str(day),
                    width=26,
                    command=lambda d=day: self._select_day(d),
                )
                btn.grid(row=row, column=col, padx=1, pady=1)
            row += 1

    def _select_day(self, day: int):
        date_str = f"{self._year:04d}-{self._month:02d}-{day:02d}"
        self._entry.delete(0, "end")
        self._entry.insert(0, date_str)
        if self._popup is not None:
            self._popup.destroy()
            self._popup = None

    def _prev_month(self):
        if self._month == 1:
            self._month = 12
            self._year -= 1
        else:
            self._month -= 1
        self._build_calendar()

    def _next_month(self):
        if self._month == 12:
            self._month = 1
            self._year += 1
        else:
            self._month += 1
        self._build_calendar()


