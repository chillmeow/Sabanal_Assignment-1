# modules/journal_page.py
import os
import csv
from datetime import datetime
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# Try to import openpyxl; if missing, we'll fallback to CSV export.
try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, numbers
    OPENPYXL_AVAILABLE = True
except Exception:
    OPENPYXL_AVAILABLE = False

from db import bootstrap_from_json, get_all_transactions


DATA_DIR = "data"
CSV_FILE = os.path.join(DATA_DIR, "transactions.csv")


def ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)


def load_transactions_from_csv():
    if not os.path.exists(CSV_FILE):
        return None
    try:
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            return [r for r in reader]
    except Exception:
        return None


def load_transactions():
    """
    Load journal rows from SQLite (primary) or legacy CSV (fallback).
    """
    ensure_data_dir()
    bootstrap_from_json()

    rows = get_all_transactions()
    if rows:
        return rows

    csv_rows = load_transactions_from_csv()
    if csv_rows is not None:
        return csv_rows
    return []


def fmt_amount(v):
    try:
        f = float(v)
        return f"{f:,.2f}"
    except Exception:
        return v or ""


class JournalPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")
        self.pack_propagate(False)

        title = ctk.CTkLabel(self, text="Journal", font=("Segoe UI", 20, "bold"), text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        top_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        top_frame.pack(fill="x", padx=18, pady=(0, 12))

        btn_frame = ctk.CTkFrame(top_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=12, pady=12)

        self.btn_refresh = ctk.CTkButton(btn_frame, text="Refresh", width=120, command=self.load_journal)
        self.btn_refresh.pack(side="left", padx=(0, 8))

        self.btn_export = ctk.CTkButton(
            btn_frame,
            text="Export to Excel" if OPENPYXL_AVAILABLE else "Export (Excel unavailable)",
            fg_color="#00c8ff" if OPENPYXL_AVAILABLE else "#b35b00",
            hover_color="#00a4cc" if OPENPYXL_AVAILABLE else "#a04d00",
            width=200,
            command=self.export_dialog
        )
        self.btn_export.pack(side="left", padx=(0, 8))

        table_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        table_frame.pack(fill="both", expand=True, padx=18, pady=(6, 18))

        cols = ("date", "particulars", "post_ref", "debit", "credit")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=18)
        self.tree.heading("date", text="Date")
        self.tree.heading("particulars", text="Particulars")
        self.tree.heading("post_ref", text="Post Ref")
        self.tree.heading("debit", text="Debit")
        self.tree.heading("credit", text="Credit")

        self.tree.column("date", width=120, anchor="w")
        self.tree.column("particulars", width=520, anchor="w")
        self.tree.column("post_ref", width=120, anchor="center")
        self.tree.column("debit", width=140, anchor="e")
        self.tree.column("credit", width=140, anchor="e")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        # Horizontal scrollbar removed to simplify the layout; columns are sized to fit.
        self.tree.configure(yscroll=vsb.set)

        self.tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y")

        hint = ctk.CTkLabel(self, text="Journal layout: debit line, indented credit line, then description line.",
                            text_color="#9fbfdc", font=("Segoe UI", 10))
        hint.pack(anchor="w", padx=26, pady=(0, 8))

        self.load_journal()

    def load_journal(self):
        self.tree.delete(*self.tree.get_children())
        rows = load_transactions()

        def sort_key(r):
            d = r.get("date", "") or r.get("created_at", "")
            try:
                return datetime.strptime(d, "%Y-%m-%d")
            except Exception:
                return d

        try:
            rows = sorted(rows, key=sort_key)
        except Exception:
            pass

        for r in rows:
            tid = r.get("id", r.get("txn_id", ""))
            date = r.get("date", "")
            desc = r.get("description", r.get("desc", ""))
            d_code = r.get("debit_acc_code", r.get("debit_code", "")) or r.get("debit_acc", "")
            d_name = r.get("debit_acc_name", r.get("debit_name", "")) or r.get("debit_account", "")
            c_code = r.get("credit_acc_code", r.get("credit_code", "")) or r.get("credit_acc", "")
            c_name = r.get("credit_acc_name", r.get("credit_name", "")) or r.get("credit_account", "")
            d_amt = r.get("debit_amt", r.get("debit", "")) or r.get("amount_debit", "")
            c_amt = r.get("credit_amt", r.get("credit", "")) or r.get("amount_credit", "")

            d_amt_str = fmt_amount(d_amt)
            c_amt_str = fmt_amount(c_amt)

            particulars_debit = f"{d_code} - {d_name}" if d_code or d_name else d_name or d_code
            self.tree.insert("", "end", values=(date, particulars_debit, d_code, d_amt_str, ""))

            particulars_credit = "    " + (f"{c_code} - {c_name}" if c_code or c_name else c_name or c_code)
            self.tree.insert("", "end", values=("", particulars_credit, c_code, "", c_amt_str))

            desc_line = "    " + (desc or "")
            self.tree.insert("", "end", values=("", desc_line, "", "", ""))

    def export_dialog(self):
        # If openpyxl available, do xlsx export. Otherwise ask to export CSV.
        if OPENPYXL_AVAILABLE:
            self.export_excel()
        else:
            if messagebox.askyesno("openpyxl missing",
                                   "openpyxl is not installed. Export to CSV instead? (Excel .xlsx requires openpyxl)"):
                self.export_csv()
            else:
                messagebox.showinfo("Canceled", "Install openpyxl to enable Excel exports:\n\npip install openpyxl")

    def export_csv(self):
        rows = []
        for iid in self.tree.get_children():
            vals = self.tree.item(iid, "values")
            if not vals:
                continue
            vals = list(vals)
            while len(vals) < 5:
                vals.append("")
            rows.append(vals)

        if not rows:
            messagebox.showinfo("Export", "No journal rows to export.")
            return

        ensure_data_dir()
        default_name = f"journal_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=default_name,
                                            filetypes=[("CSV File", "*.csv")])
        if not path:
            return

        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Date", "Particulars", "Post Ref", "Debit", "Credit"])
                for r in rows:
                    writer.writerow(r)
            messagebox.showinfo("Exported", f"Journal exported to CSV:\n{path}")
        except Exception as ex:
            messagebox.showerror("Export Error", f"Failed to export CSV:\n{ex}")

    def export_excel(self):
        # Build rows from tree preserving displayed order
        rows = []
        for iid in self.tree.get_children():
            vals = self.tree.item(iid, "values")
            if not vals:
                continue
            vals = list(vals)
            while len(vals) < 5:
                vals.append("")
            rows.append(vals)

        if not rows:
            messagebox.showinfo("Export", "No journal rows to export.")
            return

        ensure_data_dir()
        default_name = f"journal_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile=default_name,
                                            filetypes=[("Excel Workbook", "*.xlsx")])
        if not path:
            return

        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Journal"
            headers = ["Date", "Particulars", "Post Ref", "Debit", "Credit"]
            ws.append(headers)
            for row in rows:
                ws.append(row)

            ws.column_dimensions["A"].width = 14
            ws.column_dimensions["B"].width = 50
            ws.column_dimensions["C"].width = 12
            ws.column_dimensions["D"].width = 14
            ws.column_dimensions["E"].width = 14

            for r_idx in range(2, ws.max_row + 1):
                d_cell = ws.cell(row=r_idx, column=4)
                e_cell = ws.cell(row=r_idx, column=5)
                try:
                    if d_cell.value not in (None, ""):
                        v = float(str(d_cell.value).replace(",", ""))
                        d_cell.value = v
                        d_cell.number_format = numbers.FORMAT_NUMBER_COMMA_SEPARATED1
                except Exception:
                    pass
                try:
                    if e_cell.value not in (None, ""):
                        v2 = float(str(e_cell.value).replace(",", ""))
                        e_cell.value = v2
                        e_cell.number_format = numbers.FORMAT_NUMBER_COMMA_SEPARATED1
                except Exception:
                    pass

            for c in range(1, 6):
                ws.cell(row=1, column=c).font = Font(bold=True)

            wb.save(path)
            messagebox.showinfo("Exported", f"Journal exported to:\n{path}")
        except Exception as ex:
            messagebox.showerror("Export Error", f"Failed to export Excel file:\n{ex}")
