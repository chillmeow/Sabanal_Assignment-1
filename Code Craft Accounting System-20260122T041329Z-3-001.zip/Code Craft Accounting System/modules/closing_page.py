# modules/closing_page.py
from datetime import datetime
import decimal
import tkinter as tk
from tkinter import ttk, messagebox

import customtkinter as ctk

from db import (
    bootstrap_from_json,
    get_all_transactions,
    get_all_accounts,
    upsert_transaction,
    delete_transactions_by_closing_batch,
)

# decimal helper
def to_decimal(x):
    try:
        return decimal.Decimal(str(x))
    except Exception:
        return decimal.Decimal("0.00")

def load_coa():
    """
    Accepts multiple possible COA shapes:
     - {"ASSETS": [...], "LIABILITIES": [...], ...}
     - {"accounts": [ {number:, name:, group:}, ... ]}
     - [ ["101","Cash"], ... ] or [ {"code":..,"name":.., "group":..}, ... ]
    Returns normalized dict: { "ASSETS": [ {code,name,group}, ...], ... }
    """
    data = get_all_accounts()
    out = {"ASSETS": [], "LIABILITIES": [], "EQUITY": [], "INCOME": [], "EXPENSES": []}
    for a in data:
        code = str(a.get("number", "")).strip()
        name = a.get("name", "")
        grp = str(a.get("group", "")).strip().upper()
        if grp.startswith("ASSET"):
            out["ASSETS"].append({"code": code, "name": name})
        elif grp.startswith("LIAB"):
            out["LIABILITIES"].append({"code": code, "name": name})
        elif grp.startswith("EQU"):
            out["EQUITY"].append({"code": code, "name": name})
        elif grp.startswith("INC"):
            out["INCOME"].append({"code": code, "name": name})
        elif grp.startswith("EXP"):
            out["EXPENSES"].append({"code": code, "name": name})
    return out

def generate_id():
    rows = get_all_transactions()
    return str(len(rows) + 1)

class ClosingPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")
        bootstrap_from_json()
        self.coa = load_coa()
        # Initial load of all transactions from the DB
        self.transactions = get_all_transactions()

        title = ctk.CTkLabel(self, text="Closing", font=("Segoe UI", 20, "bold"), text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=18, pady=(0,18))

        info = ctk.CTkLabel(main, text="Run closing entries to move revenue/expense balances to capital.", wraplength=900)
        info.pack(anchor="nw", padx=6, pady=(8,12))

        btn_frame = ctk.CTkFrame(main, fg_color="transparent")
        btn_frame.pack(anchor="nw", padx=6, pady=(4,12))

        self.btn_run = ctk.CTkButton(btn_frame, text="Run Closing", fg_color="#00c8ff", command=self.run_closing)
        self.btn_run.pack(side="left", padx=(0,8))
        self.btn_undo = ctk.CTkButton(btn_frame, text="Undo Last Closing", fg_color="#b30000", command=self.undo_last_closing)
        self.btn_undo.pack(side="left")

        # summary area
        self.summary_box = tk.Text(main, height=18, bg="#07121a", fg="#dceffb", bd=0)
        self.summary_box.pack(fill="both", expand=True, padx=6, pady=(12,6))
        self.summary_box.insert("end", "Closing summary will appear here.\n")
        self.summary_box.configure(state="disabled")

        # refresh internal data
        self._reload_data()

    def _reload_data(self):
        self.coa = load_coa()
        self.transactions = get_all_transactions()

    def _log(self, text):
        self.summary_box.configure(state="normal")
        self.summary_box.insert("end", f"{text}\n")
        self.summary_box.see("end")
        self.summary_box.configure(state="disabled")

    def _compute_account_balances(self):
        """
        Returns dict: code -> {debits: Decimal, credits: Decimal}
        Only consider posted transactions.
        """
        balances = {}
        for t in self.transactions:
            if t.get("status") != "posted":
                continue
            dcode = str(t.get("debit_acc_code", "")).strip()
            ccode = str(t.get("credit_acc_code", "")).strip()
            da = to_decimal(t.get("debit_amt", 0))
            ca = to_decimal(t.get("credit_amt", 0))

            if dcode:
                if dcode not in balances:
                    balances[dcode] = {"debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")}
                balances[dcode]["debits"] += da
            if ccode:
                if ccode not in balances:
                    balances[ccode] = {"debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")}
                balances[ccode]["credits"] += ca
        return balances

    def _find_capital_account(self):
        # prefer 301 if present
        for cat in ("EQUITY",):
            accts = self.coa.get(cat, [])
            for a in accts:
                code = a.get("code")
                if code == "301" or str(code).strip() == "301":
                    return code, a.get("name")
        # otherwise first equity account
        eq = self.coa.get("EQUITY", [])
        if eq:
            return eq[0].get("code"), eq[0].get("name")
        # fallback: try code 301 anyway
        return "301", "Owner's Capital"

    def run_closing(self):
        # confirm
        if not messagebox.askyesno("Confirm", "This will create closing entries (posted) that zero income/expense accounts and transfer net to capital. Proceed?"):
            return

        self._reload_data()
        balances = self._compute_account_balances()
        capital_code, capital_name = self._find_capital_account()

        created = []
        # Process Revenue accounts (INCOME) - normal credit; to zero we debit revenue and credit capital
        income_accts = self.coa.get("INCOME", [])
        for acct in income_accts:
            code = str(acct.get("code")).strip()
            name = acct.get("name", "")
            b = balances.get(code, {"debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")})
            # net credit balance = credits - debits
            net_credit = b["credits"] - b["debits"]
            if net_credit > 0:
                txn = {
                    "id": generate_id(),
                    "date": datetime.now().strftime("%Y-%m-%d"),
                    "description": f"Closing - zero revenue ({name})",
                    "debit_acc_code": code,
                    "debit_acc_name": name,
                    "credit_acc_code": str(capital_code),
                    "credit_acc_name": str(capital_name),
                    "debit_amt": str(net_credit),
                    "credit_amt": str(net_credit),
                    "adjusting": 0,
                    "scheduled_reversal": 0,
                    "reversal_date": "",
                    "status": "posted",
                    "created_at": datetime.now().isoformat(),
                    "closing": True
                }
                created.append(txn)
                # update balances in-memory for subsequent closes
                balances.setdefault(capital_code, {"debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")})
                balances[code]["debits"] += net_credit
                balances[capital_code]["credits"] += net_credit

        # Process Expense accounts (EXPENSES) - normal debit; to zero we credit expense and debit capital
        expense_accts = self.coa.get("EXPENSES", [])
        for acct in expense_accts:
            code = str(acct.get("code")).strip()
            name = acct.get("name", "")
            b = balances.get(code, {"debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")})
            # net debit balance = debits - credits
            net_debit = b["debits"] - b["credits"]
            if net_debit > 0:
                txn = {
                    "id": generate_id(),
                    "date": datetime.now().strftime("%Y-%m-%d"),
                    "description": f"Closing - zero expense ({name})",
                    "debit_acc_code": str(capital_code),
                    "debit_acc_name": str(capital_name),
                    "credit_acc_code": code,
                    "credit_acc_name": name,
                    "debit_amt": str(net_debit),
                    "credit_amt": str(net_debit),
                    "adjusting": 0,
                    "scheduled_reversal": 0,
                    "reversal_date": "",
                    "status": "posted",
                    "created_at": datetime.now().isoformat(),
                    "closing": True
                }
                created.append(txn)
                # update balances in-memory
                balances.setdefault(capital_code, {"debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")})
                balances[code]["credits"] += net_debit
                balances[capital_code]["debits"] += net_debit

        if not created:
            messagebox.showinfo("No Closing", "No income or expense balances found to close.")
            return

        # mark a batch token to allow undo - we put created_at timestamp for batch id
        batch_token = datetime.now().isoformat()
        for t in created:
            t["_closing_batch"] = batch_token
            t["closing"] = 1
            t["status"] = "posted"
            upsert_transaction(t)

        # show summary
        self._log(f"Created {len(created)} closing entries (batch {batch_token}):")
        total_revenue = decimal.Decimal("0.00")
        total_expenses = decimal.Decimal("0.00")
        for t in created:
            self._log(f" - {t['date']}: {t['description']} | {t['debit_acc_code']} {t['debit_amt']} -> {t['credit_acc_code']}")
            # categorize
            if t["debit_acc_code"] and t["debit_acc_code"].startswith("4"):
                total_revenue += to_decimal(t["debit_amt"])
            elif t["credit_acc_code"] and t["credit_acc_code"].startswith("5"):
                total_expenses += to_decimal(t["debit_amt"])
            else:
                # some entries debit capital or credit capital
                pass

        # compute net (we can also compute from balances)
        # re-load transactions and compute net income
        new_balances = self._compute_account_balances()
        # compute net income: sum credits of incomes - sum debits of incomes OR total capital change from batch
        # simple approach: compute total revenue & expense from COA and balances before/after not necessary now
        self._log(f"Closing batch saved. Capital account used: {capital_code} - {capital_name}")
        messagebox.showinfo("Closing Complete", f"Created {len(created)} closing transactions and posted them.")

        # refresh data
        self._reload_data()

    def undo_last_closing(self):
        if not messagebox.askyesno("Confirm Undo", "This will remove the most recent closing batch created by this tool. Proceed?"):
            return
        txs = get_all_transactions()
        # find most recent transaction that has "_closing_batch"
        last_batch = None
        for t in reversed(txs):
            if t.get("_closing_batch"):
                last_batch = t.get("_closing_batch")
                break
        if not last_batch:
            messagebox.showinfo("Nothing to Undo", "No closing batch found to undo.")
            return
        # remove all with that batch token
        # Remove all with that batch token via DB helper
        delete_transactions_by_closing_batch(last_batch)
        removed = sum(1 for t in txs if t.get("_closing_batch") == last_batch)
        self._log(f"Undid closing batch {last_batch}. Removed {removed} transactions.")
        messagebox.showinfo("Undo Complete", f"Removed {removed} closing transactions from batch {last_batch}.")
        self._reload_data()
