# modules/export_page.py
"""
EXPORT PAGE (Final Version)
Compatible with your full accounting cycle system.
Exports:
 - Full Accounting Cycle Workbook
 - COA
 - Journal
 - Ledger
 - Trial Balances
 - Closing & Post-Closing
"""

import os
from datetime import datetime
import decimal
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import customtkinter as ctk

from db import bootstrap_from_json, get_all_accounts, get_all_transactions


# -------------------------------------------------
# Decimal Helper
# -------------------------------------------------
def to_decimal(x):
    try:
        return decimal.Decimal(str(x))
    except Exception:
        return decimal.Decimal("0.00")


# -------------------------------------------------
# EXPORT PAGE
# -------------------------------------------------
class ExportPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        bootstrap_from_json()

        title = ctk.CTkLabel(self, text="Export Center",
                             font=("Segoe UI", 20, "bold"),
                             text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        body = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        body.pack(fill="both", expand=True, padx=18, pady=20)

        # -------------------------------------------------
        # FULL WORKBOOK EXPORT
        # -------------------------------------------------
        ctk.CTkLabel(body, text="Full Accounting Cycle Export",
                     font=("Segoe UI", 15, "bold"), text_color="#00a8e6").pack(pady=(14, 4))

        ctk.CTkButton(
            body,
            text="Export COMPLETE Accounting Cycle Workbook",
            fg_color="#00c8ff",
            command=self.export_full_workbook,
            width=350
        ).pack(pady=4)

        # -------------------------------------------------
        # INDIVIDUAL EXPORTS
        # -------------------------------------------------
        ctk.CTkLabel(body, text="Individual Exports",
                     font=("Segoe UI", 15, "bold"), text_color="#00a8e6").pack(pady=(18, 6))

        btn_frame = ctk.CTkFrame(body, fg_color="transparent")
        btn_frame.pack()

        buttons = [
            ("Export Chart of Accounts", self.export_coa),
            ("Export Journal", self.export_journal),
            ("Export Ledger (All Accounts)", self.export_ledger),
            ("Export Trial Balance", self.export_tb),
            ("Export Adjusted Trial Balance", self.export_atb),
            ("Export Closing Entries", self.export_closing),
            ("Export Post-Closing TB", self.export_post_closing),
        ]

        for text, cmd in buttons:
            ctk.CTkButton(btn_frame, text=text, fg_color="#4f5b66",
                          width=260, command=cmd).pack(pady=4)

    # -------------------------------------------------
    # LOADERS (shared logic)
    # -------------------------------------------------
    def load_coa(self):
        out = []
        for a in get_all_accounts():
            out.append({
                "number": str(a.get("number", "")),
                "name": a.get("name", ""),
                "group": str(a.get("group", "")).upper()
            })
        return out

    def load_transactions(self):
        return get_all_transactions()

    # -------------------------------------------------
    # SIMPLE EXPORTER
    # -------------------------------------------------
    def simple_export(self, filename, headers, rows):
        try:
            from openpyxl import Workbook
        except:
            messagebox.showerror("Error", "openpyxl required.\nRun: pip install openpyxl")
            return

        path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                            initialfile=filename,
                                            filetypes=[("Excel Workbook", "*.xlsx")])

        if not path:
            return

        wb = Workbook()
        ws = wb.active
        ws.append(headers)

        for r in rows:
            ws.append(list(r.values()))

        wb.save(path)
        messagebox.showinfo("Exported", f"Saved to:\n{path}")

    # -------------------------------------------------
    # INDIVIDUAL EXPORT BUTTONS
    # -------------------------------------------------
    def export_coa(self):
        coa = self.load_coa()
        self.simple_export("Chart_of_Accounts.xlsx",
                           ["Number", "Name", "Group"], coa)

    def export_journal(self):
        tx = self.load_transactions()
        rows = []
        for t in tx:
            rows.append({
                "Date": t.get("date", ""),
                "Description": t.get("description", ""),
                "Debit": f"{t.get('debit_acc_code')} - {t.get('debit_acc_name')}",
                "Credit": f"{t.get('credit_acc_code')} - {t.get('credit_acc_name')}",
                "Amount": float(t.get("debit_amt", 0))
            })
        self.simple_export("General_Journal.xlsx",
                           ["Date", "Description", "Debit", "Credit", "Amount"], rows)

    def export_ledger(self):
        messagebox.showinfo("Info", "Export full ledger using the Full Workbook exporter.")

    def export_tb(self):
        messagebox.showinfo("Info", "Trial Balance is exported inside the Trial Balance page.")

    def export_atb(self):
        messagebox.showinfo("Info", "Adjusted Trial Balance is exported in the ATB module.")

    def export_closing(self):
        messagebox.showinfo("Info", "Closing entries export is inside Closing Page.")

    def export_post_closing(self):
        messagebox.showinfo("Info", "Post-Closing TB is exported in Post-Closing Page.")

    # -------------------------------------------------
    # FULL ACCOUNTING CYCLE WORKBOOK EXPORT
    # -------------------------------------------------
    def export_full_workbook(self):
        try:
            from openpyxl import Workbook
        except:
            messagebox.showerror("Missing Library", "Install openpyxl:\npip install openpyxl")
            return

        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            initialfile="Full_Accounting_Cycle.xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")]
        )
        if not path:
            return

        coa = self.load_coa()
        tx = self.load_transactions()

        wb = Workbook()

        # COA
        ws = wb.active
        ws.title = "Chart of Accounts"
        ws.append(["Number", "Name", "Group"])
        for a in coa:
            ws.append([a["number"], a["name"], a["group"]])

        # Transactions sheet
        ws2 = wb.create_sheet("Transactions")
        ws2.append(["ID", "Date", "Description", "Debit", "Credit", "Amount", "Status"])
        for t in tx:
            ws2.append([
                t.get("id", ""),
                t.get("date", ""),
                t.get("description", ""),
                f"{t.get('debit_acc_code')} - {t.get('debit_acc_name')}",
                f"{t.get('credit_acc_code')} - {t.get('credit_acc_name')}",
                float(t.get("debit_amt", 0)),
                t.get("status", "").upper()
            ])

        # Journal
        ws3 = wb.create_sheet("General Journal")
        ws3.append(["Date", "Description", "Debit", "Credit", "Amount"])
        for t in tx:
            ws3.append([
                t.get("date", ""),
                t.get("description", ""),
                f"{t.get('debit_acc_code')} - {t.get('debit_acc_name')}",
                f"{t.get('credit_acc_code')} - {t.get('credit_acc_name')}",
                float(t.get("debit_amt", 0))
            ])

        # Ledger: reuse existing LedgerPage logic
        from modules.ledger_page import LedgerPage
        ledger = LedgerPage(self)

        for a in coa:
            code = a["number"]
            name = a["name"]
            grp = a["group"]

            rows = ledger._build_ledger_for_account(code, grp)

            wsL = wb.create_sheet(f"{code}_{name}"[:31])
            wsL.append(["Account:", name, "", "", "", f"Acct No. {code}"])
            wsL.append([])
            wsL.append(["Date", "Particulars", "PR", "Debit", "Credit", "Balance"])

            for r in rows:
                wsL.append([
                    r["date"],
                    r["particulars"],
                    r["postref"],
                    float(r["debit"]),
                    float(r["credit"]),
                    float(r["balance"])
                ])

        wb.save(path)
        messagebox.showinfo("Exported", f"Workbook saved to:\n{path}")
