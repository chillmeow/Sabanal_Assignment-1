# modules/post_closing_page.py
"""
Post-Closing Trial Balance Page (Unadjusted permanent accounts only)

- Expects data/chart_of_accounts.json (various formats supported) and data/transactions.json
- Only posted transactions (status == "posted") are taken into account (including closing entries)
- Shows only permanent accounts (Assets, Liabilities, Equity)
- Exports to Excel (requires openpyxl)
"""

import decimal
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import customtkinter as ctk

from db import bootstrap_from_json, get_all_accounts, get_posted_transactions

# Decimal helper to avoid floating errors
def to_decimal(x):
    try:
        return decimal.Decimal(str(x))
    except Exception:
        return decimal.Decimal("0.00")


class PostClosingPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        bootstrap_from_json()

        title = ctk.CTkLabel(self, text="Post-Closing Trial Balance",
                             font=("Segoe UI", 20, "bold"),
                             text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        ctrl = ctk.CTkFrame(self, fg_color="transparent")
        ctrl.pack(fill="x", padx=18, pady=(0, 8))

        self.btn_refresh = ctk.CTkButton(ctrl, text="Refresh", width=120, command=self.refresh)
        self.btn_refresh.pack(side="left", padx=(0, 8))

        self.btn_export = ctk.CTkButton(ctrl, text="Export to Excel", width=160, fg_color="#00c8ff", command=self.export_xlsx)
        self.btn_export.pack(side="left", padx=(0, 8))

        self.status_label = ctk.CTkLabel(ctrl, text="", text_color="#7fcaff", font=("Segoe UI", 12, "bold"))
        self.status_label.pack(side="right")

        # Table frame
        table_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        table_frame.pack(fill="both", expand=True, padx=18, pady=(6, 18))

        cols = ("acct_no", "acct_name", "debit", "credit")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        self.tree.heading("acct_no", text="Account No")
        self.tree.heading("acct_name", text="Account Name")
        self.tree.heading("debit", text="Debit")
        self.tree.heading("credit", text="Credit")

        self.tree.column("acct_no", width=100, anchor="center")
        self.tree.column("acct_name", width=420)
        self.tree.column("debit", width=140, anchor="e")
        self.tree.column("credit", width=140, anchor="e")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        # Horizontal scrollbar removed; 4 columns fit within the available width.
        self.tree.configure(yscroll=vsb.set)

        self.tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y")

        # Totals footer
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=18, pady=(0, 14))

        self.total_debit_label = ctk.CTkLabel(footer, text="Total Debit: 0.00", font=("Segoe UI", 12, "bold"), text_color="#7fcaff")
        self.total_debit_label.pack(side="left", padx=(4, 12))

        self.total_credit_label = ctk.CTkLabel(footer, text="Total Credit: 0.00", font=("Segoe UI", 12, "bold"), text_color="#7fcaff")
        self.total_credit_label.pack(side="left", padx=(4, 12))

        # Internal caches
        self.coa = []
        self.posted_transactions = []

        # initial render
        self.refresh(silent=True)

    # -------------------------
    # Loaders
    # -------------------------
    def _load_coa(self):
        """
        Accept various COA shapes and normalize into list of dicts:
        [ {"number": "101", "name": "Cash", "group": "ASSETS"}, ... ]
        """
        out = []
        for a in get_all_accounts():
            num = str(a.get("number", "")).strip()
            name = str(a.get("name", "")).strip()
            grp = str(a.get("group", "")).strip().upper()
            if not num:
                continue
            out.append({"number": num, "name": name, "group": grp})
        return out

    def _load_transactions(self):
        return get_posted_transactions()

    # -------------------------
    # Compute post-closing balances
    # -------------------------
    def compute_post_closing(self):
        """
        Returns:
          rows: list of (acct_no, acct_name, debit_decimal, credit_decimal)
          totals: (total_debit, total_credit)
        Only includes permanent accounts (ASSETS, LIABILITIES, EQUITY)
        """
        self.coa = self._load_coa()
        self.posted_transactions = self._load_transactions()

        # prepare mapping
        acct_map = {}
        for a in self.coa:
            num = a.get("number", "").strip()
            if not num:
                continue
            acct_map[num] = {
                "number": num,
                "name": a.get("name", ""),
                "group": a.get("group", "").strip().upper(),
                "debits": decimal.Decimal("0.00"),
                "credits": decimal.Decimal("0.00")
            }

        # accumulate posted transactions
        for t in self.posted_transactions:
            d_code = str(t.get("debit_acc_code", "")).strip()
            c_code = str(t.get("credit_acc_code", "")).strip()
            try:
                da = to_decimal(t.get("debit_amt", 0))
            except Exception:
                da = decimal.Decimal("0.00")
            try:
                ca = to_decimal(t.get("credit_amt", 0))
            except Exception:
                ca = decimal.Decimal("0.00")

            if d_code:
                acct_map.setdefault(d_code, {"number": d_code, "name": "", "group": "", "debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")})
                acct_map[d_code]["debits"] += da
            if c_code:
                acct_map.setdefault(c_code, {"number": c_code, "name": "", "group": "", "debits": decimal.Decimal("0.00"), "credits": decimal.Decimal("0.00")})
                acct_map[c_code]["credits"] += ca

        # build rows: include only ASSETS, LIABILITIES, EQUITY
        rows = []
        total_debit = decimal.Decimal("0.00")
        total_credit = decimal.Decimal("0.00")

        for acct in acct_map.values():
            grp = (acct.get("group") or "").strip().upper()
            # if group unknown, try infer by code first digit
            if not grp:
                code = str(acct.get("number",""))
                if code.startswith("1"):
                    grp = "ASSETS"
                elif code.startswith("2"):
                    grp = "LIABILITIES"
                elif code.startswith("3"):
                    grp = "EQUITY"

            if grp not in ("ASSETS", "LIABILITIES", "EQUITY"):
                continue

            debs = acct["debits"]
            cre = acct["credits"]

            # For assets: normal debit; balance = debits - credits
            if grp == "ASSETS":
                bal = debs - cre
                if bal >= decimal.Decimal("0.00"):
                    dr = bal
                    cr = decimal.Decimal("0.00")
                else:
                    dr = decimal.Decimal("0.00")
                    cr = abs(bal)
            else:
                # LIABILITIES and EQUITY: normal credit; balance = credits - debits
                bal = cre - debs
                if bal >= decimal.Decimal("0.00"):
                    cr = bal
                    dr = decimal.Decimal("0.00")
                else:
                    cr = decimal.Decimal("0.00")
                    dr = abs(bal)

            rows.append((acct["number"], acct.get("name",""), dr, cr))
            total_debit += dr
            total_credit += cr

        # sort rows by account number (numeric if possible)
        def sort_key(x):
            try:
                return int(x[0])
            except:
                return x[0]
        rows.sort(key=sort_key)

        return rows, total_debit, total_credit

    # -------------------------
    # Render
    # -------------------------
    def render(self):
        for r in self.tree.get_children():
            self.tree.delete(r)

        rows, total_debit, total_credit = self.compute_post_closing()

        for acct_no, acct_name, dr, cr in rows:
            dr_str = f"{dr:,.2f}" if dr != 0 else ""
            cr_str = f"{cr:,.2f}" if cr != 0 else ""
            self.tree.insert("", "end", values=(acct_no, acct_name, dr_str, cr_str))

        self.total_debit_label.configure(text=f"Total Debit: {total_debit:,.2f}")
        self.total_credit_label.configure(text=f"Total Credit: {total_credit:,.2f}")

        if total_debit == total_credit:
            self.status_label.configure(text="Balanced ✔", text_color="#7fffb3")
        else:
            diff = total_debit - total_credit
            self.status_label.configure(text=f"Not Balanced — Diff: {diff:,.2f}", text_color="#ff8080")

    # -------------------------
    # Refresh
    # -------------------------
    def refresh(self, silent=False):
        try:
            self.render()
            if not silent:
                messagebox.showinfo("Refreshed", "Post-Closing Trial Balance refreshed.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not refresh Post-Closing Trial Balance:\n{e}")

    # -------------------------
    # Export
    # -------------------------
    def export_xlsx(self):
        try:
            from openpyxl import Workbook
            from openpyxl.utils import get_column_letter
            from openpyxl.styles import Font, Alignment
        except Exception:
            messagebox.showerror("Missing dependency", "openpyxl is required to export to Excel. Install: pip install openpyxl")
            return

        rows, total_debit, total_credit = self.compute_post_closing()

        default_name = "Post_Closing_Trial_Balance.xlsx"
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile=default_name,
                                            filetypes=[("Excel Workbook", "*.xlsx")])
        if not path:
            return

        wb = Workbook()
        ws = wb.active
        ws.title = "Post-Closing TB"

        ws.append(["Post-Closing Trial Balance"])
        ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
        ws.append([])
        ws.append(["Account No", "Account Name", "Debit", "Credit"])

        bold = Font(bold=True)
        for col in range(1, 5):
            ws.cell(row=4, column=col).font = bold
            ws.cell(row=4, column=col).alignment = Alignment(horizontal="center")

        row = 5
        for acct_no, acct_name, dr, cr in rows:
            ws.append([acct_no, acct_name, float(dr), float(cr)])
            row += 1

        ws.append([])
        ws.append(["", "TOTALS", float(total_debit), float(total_credit)])

        widths = [12, 50, 18, 18]
        for i, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w

        wb.save(path)
        messagebox.showinfo("Exported", f"Post-Closing Trial Balance exported to:\n{path}")
