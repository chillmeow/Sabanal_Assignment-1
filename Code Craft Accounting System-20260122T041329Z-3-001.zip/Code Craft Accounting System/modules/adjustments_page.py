# modules/adjustments_page.py
"""
Adjustments Module
- Create adjusting entries (debit/credit pairs)
- Save as draft or Record & Post (posted adjustments will have "adjusting": 1)
- Adjusting entries are stored in data/transactions.json (same structure as transactions)
"""

import decimal
from datetime import datetime
import uuid
import tkinter as tk
from tkinter import ttk, messagebox

import customtkinter as ctk
from widgets.date_picker import DateEntry
from db import (
    bootstrap_from_json,
    get_accounts_pairs,
    get_adjusting_transactions,
    upsert_transaction,
    delete_transaction_by_id,
)

def generate_id():
    """Fallback ID generator; DB has its own helper but we keep format similar."""
    return uuid.uuid4().hex[:8]

# -------------------------
# Adjustments Page Frame
# -------------------------
class AdjustmentsPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        bootstrap_from_json()

        pairs = get_accounts_pairs()
        self.accounts = pairs

        title = ctk.CTkLabel(self, text="Adjusting Entries", font=("Segoe UI", 20, "bold"), text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        top_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        top_frame.pack(fill="x", padx=18, pady=(0,12))

        form = ctk.CTkFrame(top_frame, fg_color="transparent")
        form.pack(fill="x", padx=18, pady=12)

        # Left column: Date, Description, reversal checkbox
        left = ctk.CTkFrame(form, fg_color="transparent")
        left.grid(row=0, column=0, sticky="nw", padx=(0,30))
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Date (YYYY-MM-DD)", text_color="#7fcaff").grid(row=0, column=0, sticky="w")
        self.date_entry = DateEntry(left, width=220, placeholder_text=datetime.now().strftime("%Y-%m-%d"))
        self.date_entry.grid(row=1, column=0, pady=(6,12), sticky="we")

        ctk.CTkLabel(left, text="Description", text_color="#7fcaff").grid(row=2, column=0, sticky="w")
        self.desc_entry = ctk.CTkEntry(left, width=300, placeholder_text="Explanation/purpose")
        self.desc_entry.grid(row=3, column=0, pady=(6,12), sticky="we")

        # Middle column: Credit & Debit accounts
        mid = ctk.CTkFrame(form, fg_color="transparent")
        mid.grid(row=0, column=1, sticky="nw", padx=(0,40))

        ctk.CTkLabel(mid, text="Account (Debit)", text_color="#7fcaff").grid(row=0, column=0, sticky="w")
        self.debit_var = tk.StringVar()
        self.debit_dd = ctk.CTkComboBox(mid, values=self._acc_list(), width=320, variable=self.debit_var)
        self.debit_dd.grid(row=1, column=0, pady=(6,12), sticky="w")

        ctk.CTkLabel(mid, text="Account (Credit)", text_color="#7fcaff").grid(row=2, column=0, sticky="w")
        self.credit_var = tk.StringVar()
        self.credit_dd = ctk.CTkComboBox(mid, values=self._acc_list(), width=320, variable=self.credit_var)
        self.credit_dd.grid(row=3, column=0, pady=(6,12), sticky="w")

        # Right column: Amounts & buttons
        right = ctk.CTkFrame(form, fg_color="transparent")
        right.grid(row=0, column=2, sticky="ne")

        ctk.CTkLabel(right, text="Amount (Debit)", text_color="#7fcaff").grid(row=0, column=0, sticky="w")
        self.debit_amt = ctk.CTkEntry(right, width=200, placeholder_text="0.00")
        self.debit_amt.grid(row=1, column=0, pady=(6,8), sticky="w")

        ctk.CTkLabel(right, text="Amount (Credit)", text_color="#7fcaff").grid(row=2, column=0, sticky="w", pady=(8,0))
        self.credit_amt = ctk.CTkEntry(right, width=200, placeholder_text="0.00")
        self.credit_amt.grid(row=3, column=0, pady=(6,8), sticky="w")

        btn_frame = ctk.CTkFrame(right, fg_color="transparent")
        btn_frame.grid(row=1, column=1, rowspan=3, padx=(8,0), sticky="n")

        self.btn_save = ctk.CTkButton(btn_frame, text="Save Draft", fg_color="#4f5b66", command=self.save_draft)
        self.btn_save.pack(pady=(0,8))
        self.btn_post = ctk.CTkButton(btn_frame, text="Record & Post", fg_color="#00c8ff", command=self.post_adjustment)
        self.btn_post.pack(pady=(0,8))
        self.btn_clear = ctk.CTkButton(btn_frame, text="Clear", fg_color="#4f5b66", command=self.clear_form)
        self.btn_clear.pack()

        # Divider
        ttk.Separator(self).pack(fill="x", padx=18, pady=(6,6))

        # Table area showing adjustments (same structure as transactions view)
        table_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        table_frame.pack(fill="both", expand=True, padx=18, pady=(6,18))
        # Use grid inside the table_frame for aligned scrollbars
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        cols = ("id", "date", "description", "debit", "credit", "status")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        self.tree.heading("id", text="ID")
        self.tree.heading("date", text="DATE")
        self.tree.heading("description", text="DESCRIPTION")
        self.tree.heading("debit", text="DEBIT (Acct)")
        self.tree.heading("credit", text="CREDIT (Acct)")
        self.tree.heading("status", text="STATUS")

        self.tree.column("id", width=60, anchor="center")
        self.tree.column("date", width=110, anchor="center")
        self.tree.column("description", width=360)
        self.tree.column("debit", width=180)
        self.tree.column("credit", width=180)
        self.tree.column("status", width=90, anchor="center")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        # Horizontal scrollbar removed; adjustment columns are sized to fit.
        self.tree.configure(yscroll=vsb.set)

        # Grid layout so the vertical scrollbar hugs the right edge.
        self.tree.grid(row=0, column=0, sticky="nsew", padx=(8,0), pady=10)
        vsb.grid(row=0, column=1, sticky="ns", pady=10)

        # Delete controls
        del_frame = ctk.CTkFrame(self, fg_color="transparent")
        del_frame.pack(fill="x", pady=(4,12))

        ctk.CTkButton(del_frame, text="Delete Selected", fg_color="#9b2a2a", hover_color="#7a1f1f", command=self.delete_selected).pack(side="left", padx=20)
        ctk.CTkButton(del_frame, text="Delete All", fg_color="#b30000", hover_color="#8e0000", command=self.delete_all).pack(side="left", padx=10)
        ctk.CTkButton(del_frame, text="Refresh", fg_color="#00c8ff", command=self.refresh).pack(side="right", padx=12)

        # Load existing adjustments (transactions with adjusting==1)
        self.refresh()

    # -------------------------
    # Helpers
    # -------------------------
    def _acc_list(self):
        return [f"{c} - {n}" for c, n in self.accounts]

    def clear_form(self):
        self.date_entry.delete(0, "end")
        self.date_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.desc_entry.delete(0, "end")
        self.debit_dd.set("")
        self.credit_dd.set("")
        self.debit_amt.delete(0, "end")
        self.credit_amt.delete(0, "end")

    def _gather_form(self):
        date = self.date_entry.get().strip()
        desc = self.desc_entry.get().strip()
        debit_sel = self.debit_dd.get().strip()
        credit_sel = self.credit_dd.get().strip()
        debit_amt = self.debit_amt.get().strip()
        credit_amt = self.credit_amt.get().strip()

        if not all([date, desc, debit_sel, credit_sel, debit_amt, credit_amt]):
            messagebox.showerror("Missing", "All fields are required.")
            return None

        try:
            datetime.strptime(date, "%Y-%m-%d")
        except:
            messagebox.showerror("Date", "Date must be YYYY-MM-DD.")
            return None

        try:
            da = float(debit_amt)
            ca = float(credit_amt)
        except:
            messagebox.showerror("Amount", "Amounts must be numeric.")
            return None

        # parse account selections "code - name"
        def parse(x):
            parts = x.split(" - ", 1)
            if len(parts) == 2:
                return parts[0].strip(), parts[1].strip()
            else:
                return x.strip(), x.strip()

        d_code, d_name = parse(debit_sel)
        c_code, c_name = parse(credit_sel)

        payload = {
            "id": generate_id(),
            "date": date,
            "description": desc,
            "debit_acc_code": d_code,
            "debit_acc_name": d_name,
            "credit_acc_code": c_code,
            "credit_acc_name": c_name,
            "debit_amt": f"{da}",
            "credit_amt": f"{ca}",
            "adjusting": 1,
            "scheduled_reversal": 0,
            "reversal_date": "",
            "status": "draft",
            "created_at": datetime.now().isoformat()
        }
        return payload

    # -------------------------
    # Actions
    # -------------------------
    def save_draft(self):
        payload = self._gather_form()
        if not payload:
            return
        payload["status"] = "draft"
        upsert_transaction(payload)
        messagebox.showinfo("Saved", "Draft saved.")
        self.refresh()
        self.clear_form()

    def post_adjustment(self):
        payload = self._gather_form()
        if not payload:
            return

        # require equality of amounts
        if abs(float(payload["debit_amt"]) - float(payload["credit_amt"])) > 0.0001:
            messagebox.showerror("Mismatch", "Debit and credit amounts must be equal.")
            return

        payload["status"] = "posted"
        payload["adjusting"] = 1
        upsert_transaction(payload)
        messagebox.showinfo("Posted", "Adjustment recorded and posted.")
        self.refresh()
        self.clear_form()

    def refresh(self):
        # reload adjustments (transactions where adjusting == 1) from DB
        for r in self.tree.get_children():
            self.tree.delete(r)

        recs = get_adjusting_transactions()
        for row in recs:
            status = row.get("status", "")
            debit_display = f"{row.get('debit_acc_code','')} - {row.get('debit_acc_name','')} : {row.get('debit_amt','')}"
            credit_display = f"{row.get('credit_acc_code','')} - {row.get('credit_acc_name','')} : {row.get('credit_amt','')}"
            self.tree.insert("", "end", values=(row.get("id",""), row.get("date",""), row.get("description",""), debit_display, credit_display, status))

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("None", "No selection.")
            return
        rid = self.tree.item(sel[0], "values")[0]
        delete_transaction_by_id(rid)
        messagebox.showinfo("Deleted", "Record deleted.")
        self.refresh()

    def delete_all(self):
        if not messagebox.askyesno("Confirm", "Delete all adjusting records?"):
            return
        # Delete only adjusting entries
        recs = get_adjusting_transactions()
        for r in recs:
            if int(r.get("adjusting", 0) or 0) == 1:
                delete_transaction_by_id(r.get("id", ""))
        messagebox.showinfo("Cleared", "All adjusting records removed.")
        self.refresh()
