# modules/income_statement_page.py
"""
Income Statement Module
- Pulls Adjusted Totals for each account
- Summarizes:
      Total Income
      Total Expenses
      Net Income / Net Loss
- Auto-updates when new posted transactions exist
"""

import decimal
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import customtkinter as ctk

from accounting import generate_financial_statements
from db import bootstrap_from_json, get_all_accounts, get_posted_transactions

def to_decimal(x):
    try:
        return decimal.Decimal(str(x))
    except:
        return decimal.Decimal("0.00")


class IncomeStatementPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        bootstrap_from_json()

        title = ctk.CTkLabel(
            self,
            text="Financial Statements",
            font=("Segoe UI", 20, "bold"),
            text_color="#00c8ff",
        )
        title.pack(anchor="nw", padx=20, pady=(18, 6))

        # Buttons
        ctrl_frame = ctk.CTkFrame(self, fg_color="transparent")
        ctrl_frame.pack(fill="x", padx=18, pady=(0, 10))

        ctk.CTkButton(ctrl_frame, text="Refresh",
            width=120, command=self.refresh).pack(side="left", padx=(0, 8))

        ctk.CTkButton(ctrl_frame, text="Export to Excel",
            width=150, fg_color="#00c8ff",
            command=self.export_excel).pack(side="left")

        # Tabbed Financial Statements: IS, Equity, Balance Sheet, Cash Flow/Notes
        tabs = ctk.CTkTabview(self, fg_color="#07121a")
        tabs.pack(fill="both", expand=True, padx=18, pady=(6, 18))

        self.tab_is = tabs.add("Income Statement")
        self.tab_equity = tabs.add("Changes in Equity")
        self.tab_bs = tabs.add("Balance Sheet")
        self.tab_cf = tabs.add("Cash Flow & Notes")

        # Income Statement table
        frame_is = ctk.CTkFrame(self.tab_is, fg_color="#07121a", corner_radius=8)
        frame_is.pack(fill="both", expand=True, padx=8, pady=8)

        cols = ("name", "amount")
        self.tree_is = ttk.Treeview(frame_is, columns=cols, show="headings")
        self.tree_is.heading("name", text="Account")
        self.tree_is.heading("amount", text="Amount")
        self.tree_is.column("name", width=350)
        self.tree_is.column("amount", width=150, anchor="e")
        vsb_is = ttk.Scrollbar(frame_is, orient="vertical", command=self.tree_is.yview)
        self.tree_is.configure(yscroll=vsb_is.set)
        self.tree_is.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        vsb_is.pack(side="right", fill="y")

        self.footer_is = ctk.CTkLabel(
            self.tab_is,
            text="",
            text_color="#7fcaff",
            font=("Segoe UI", 14, "bold"),
        )
        self.footer_is.pack(padx=8, pady=(0, 10))

        # Statement of Changes in Equity
        frame_eq = ctk.CTkFrame(self.tab_equity, fg_color="#07121a", corner_radius=8)
        frame_eq.pack(fill="both", expand=True, padx=8, pady=8)

        cols_eq = ("label", "amount")
        self.tree_eq = ttk.Treeview(frame_eq, columns=cols_eq, show="headings")
        self.tree_eq.heading("label", text="Item")
        self.tree_eq.heading("amount", text="Amount")
        self.tree_eq.column("label", width=260)
        self.tree_eq.column("amount", width=140, anchor="e")
        vsb_eq = ttk.Scrollbar(frame_eq, orient="vertical", command=self.tree_eq.yview)
        self.tree_eq.configure(yscroll=vsb_eq.set)
        self.tree_eq.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        vsb_eq.pack(side="right", fill="y")

        # Balance Sheet
        frame_bs = ctk.CTkFrame(self.tab_bs, fg_color="#07121a", corner_radius=8)
        frame_bs.pack(fill="both", expand=True, padx=8, pady=8)

        cols_bs = ("section", "name", "amount")
        self.tree_bs = ttk.Treeview(frame_bs, columns=cols_bs, show="headings")
        self.tree_bs.heading("section", text="Section")
        self.tree_bs.heading("name", text="Account")
        self.tree_bs.heading("amount", text="Amount")
        self.tree_bs.column("section", width=120)
        self.tree_bs.column("name", width=280)
        self.tree_bs.column("amount", width=140, anchor="e")
        vsb_bs = ttk.Scrollbar(frame_bs, orient="vertical", command=self.tree_bs.yview)
        self.tree_bs.configure(yscroll=vsb_bs.set)
        self.tree_bs.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        vsb_bs.pack(side="right", fill="y")

        # Cash Flow & Notes
        frame_cf = ctk.CTkFrame(self.tab_cf, fg_color="#07121a", corner_radius=8)
        frame_cf.pack(fill="both", expand=True, padx=8, pady=8)

        cols_cf = ("section", "label", "amount")
        self.tree_cf = ttk.Treeview(frame_cf, columns=cols_cf, show="headings")
        self.tree_cf.heading("section", text="Section")
        self.tree_cf.heading("label", text="Description")
        self.tree_cf.heading("amount", text="Amount")
        self.tree_cf.column("section", width=160)
        self.tree_cf.column("label", width=320)
        self.tree_cf.column("amount", width=140, anchor="e")
        vsb_cf = ttk.Scrollbar(frame_cf, orient="vertical", command=self.tree_cf.yview)
        self.tree_cf.configure(yscroll=vsb_cf.set)
        self.tree_cf.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        vsb_cf.pack(side="right", fill="y")

        # Cache account names for nicer labeling in Balance Sheet
        self.account_names = self._load_account_names()

        self.refresh()

    # -----------------------
    # Loaders
    # -----------------------
    def load_coa(self):
        return get_all_accounts()

    def load_transactions(self):
        return get_posted_transactions()

    # -----------------------
    # Adjusted Trial Balance Logic (same as the ATB page)
    # -----------------------
    def compute_adjusted_totals(self):
        coa = self.load_coa()
        txs = self.load_transactions()

        acct_map = {}
        for a in coa:
            num = str(a["number"])
            acct_map[num] = {
                "name": a["name"],
                "group": a["group"].title(),
                "un_dr": decimal.Decimal("0"),
                "un_cr": decimal.Decimal("0"),
                "adj_dr": decimal.Decimal("0"),
                "adj_cr": decimal.Decimal("0"),
            }

        for t in txs:
            d = str(t.get("debit_acc_code", "")).strip()
            c = str(t.get("credit_acc_code", "")).strip()

            da = to_decimal(t.get("debit_amt", 0))
            ca = to_decimal(t.get("credit_amt", 0))

            is_adj = bool(int(t.get("adjusting", 0)))

            if is_adj:
                if d in acct_map: acct_map[d]["adj_dr"] += da
                if c in acct_map: acct_map[c]["adj_cr"] += ca
            else:
                if d in acct_map: acct_map[d]["un_dr"] += da
                if c in acct_map: acct_map[c]["un_cr"] += ca

        adjusted = {}
        for num, data in acct_map.items():
            net = (data["un_dr"] - data["un_cr"]) + (data["adj_dr"] - data["adj_cr"])
            adjusted[num] = {
                "name": data["name"],
                "group": data["group"],
                "debit": net if net > 0 else decimal.Decimal("0"),
                "credit": abs(net) if net < 0 else decimal.Decimal("0")
            }

        return adjusted

    def _load_account_names(self):
        names = {}
        for acc in get_all_accounts():
            code = str(acc.get("number", "")).strip()
            if code:
                names[code] = acc.get("name", code)
        return names

    def _acct_label(self, code):
        return self.account_names.get(str(code), str(code))

    # -----------------------
    # Render Financial Statements
    # -----------------------
    def refresh(self):
        # Clear all trees
        for tree in (self.tree_is, self.tree_eq, self.tree_bs, self.tree_cf):
            for row in tree.get_children():
                tree.delete(row)

        # Reuse existing adjusted totals for detailed Income Statement lines
        data = self.compute_adjusted_totals()

        total_income = decimal.Decimal("0")
        total_expense = decimal.Decimal("0")

        # Income Section
        self.tree_is.insert("", "end", values=("--- INCOME ---", ""))
        for _, a in data.items():
            if a["group"] == "Income":
                amount = a["credit"]  # income normally credit
                total_income += amount
                self.tree_is.insert("", "end", values=(a["name"], f"{amount:,.2f}"))

        # Total Income
        self.tree_is.insert("", "end", values=("", ""))
        self.tree_is.insert("", "end", values=("Total Income", f"{total_income:,.2f}"))
        self.tree_is.insert("", "end", values=("", ""))

        # Expense Section
        self.tree_is.insert("", "end", values=("--- EXPENSES ---", ""))
        for _, a in data.items():
            if a["group"] == "Expenses":
                amount = a["debit"]  # expenses normally debit
                total_expense += amount
                self.tree_is.insert("", "end", values=(a["name"], f"{amount:,.2f}"))

        # Total Expenses
        self.tree_is.insert("", "end", values=("", ""))
        self.tree_is.insert("", "end", values=("Total Expenses", f"{total_expense:,.2f}"))

        net_income = total_income - total_expense
        if net_income >= 0:
            self.footer_is.configure(text=f"Net Income: {net_income:,.2f}")
        else:
            self.footer_is.configure(text=f"Net Loss: {abs(net_income):,.2f}")

        # Use core accounting helper to build Equity & Balance Sheet
        fs = generate_financial_statements()

        soeq = fs["statement_of_owner_equity"]
        self.tree_eq.insert("", "end", values=("Beginning Capital", f"{soeq['beginning_capital']:,.2f}"))
        self.tree_eq.insert("", "end", values=("Add: Net Income", f"{soeq['net_income']:,.2f}"))
        self.tree_eq.insert("", "end", values=("Less: Withdrawals", f"{soeq['withdrawals']:,.2f}"))
        self.tree_eq.insert("", "end", values=("", ""))
        self.tree_eq.insert("", "end", values=("Ending Capital", f"{soeq['ending_capital']:,.2f}"))

        bs = fs["balance_sheet"]
        assets = bs["assets"]
        liabs = bs["liabilities"]
        equity = bs["equity"]

        total_assets = 0.0
        total_liabs = 0.0
        total_equity = 0.0

        self.tree_bs.insert("", "end", values=("ASSETS", "", ""))
        for code, bal in assets.items():
            total_assets += bal
            self.tree_bs.insert("", "end", values=("Asset", self._acct_label(code), f"{bal:,.2f}"))
        self.tree_bs.insert("", "end", values=("", "", ""))
        self.tree_bs.insert("", "end", values=("Total Assets", "", f"{total_assets:,.2f}"))

        self.tree_bs.insert("", "end", values=("", "", ""))
        self.tree_bs.insert("", "end", values=("LIABILITIES", "", ""))
        for code, bal in liabs.items():
            total_liabs += bal
            self.tree_bs.insert("", "end", values=("Liability", self._acct_label(code), f"{bal:,.2f}"))
        self.tree_bs.insert("", "end", values=("", "", ""))
        self.tree_bs.insert("", "end", values=("Total Liabilities", "", f"{total_liabs:,.2f}"))

        self.tree_bs.insert("", "end", values=("", "", ""))
        self.tree_bs.insert("", "end", values=("EQUITY", "", ""))
        for code, bal in equity.items():
            total_equity += bal
            self.tree_bs.insert("", "end", values=("Equity", self._acct_label(code), f"{bal:,.2f}"))
        self.tree_bs.insert("", "end", values=("", "", ""))
        self.tree_bs.insert("", "end", values=("Total Equity", "", f"{total_equity:,.2f}"))

        self.tree_bs.insert("", "end", values=("", "", ""))
        self.tree_bs.insert("", "end", values=("Total Liabilities & Equity", "", f"{(total_liabs + total_equity):,.2f}"))

        # Very simple Cash Flow summary (indirect method, basic approximation)
        # We reuse the same financial statements helper to stay consistent.
        cf_is = fs["income_statement"]
        soeq = fs["statement_of_owner_equity"]

        net_income_cf = decimal.Decimal(str(cf_is["net_income"]))
        withdrawals_cf = decimal.Decimal(str(soeq["withdrawals"]))

        # Cash from operations is approximated as net income here (no non‑cash adj tracked)
        self.tree_cf.insert("", "end", values=("OPERATING", "Net income (loss)", f"{net_income_cf:,.2f}"))
        self.tree_cf.insert("", "end", values=("OPERATING", "Net cash provided by operations", f"{net_income_cf:,.2f}"))

        self.tree_cf.insert("", "end", values=("", "", ""))

        # Owner withdrawals are treated as a simple financing outflow
        self.tree_cf.insert("", "end", values=("FINANCING", "Owner withdrawals / drawings", f"{-withdrawals_cf:,.2f}"))

        self.tree_cf.insert("", "end", values=("", "", ""))

        net_change = net_income_cf - withdrawals_cf
        self.tree_cf.insert("", "end", values=("SUMMARY", "Net increase (decrease) in cash (approx.)", f"{net_change:,.2f}"))

    # -----------------------
    # Export
    # -----------------------
    def export_excel(self):
        try:
            from openpyxl import Workbook
        except:
            messagebox.showerror("Missing", "Install openpyxl to export.\n\npip install openpyxl")
            return

        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel File", "*.xlsx")],
            initialfile="Income_Statement.xlsx"
        )
        if not path:
            return

        data = self.compute_adjusted_totals()

        wb = Workbook()
        ws = wb.active
        ws.title = "Income Statement"

        ws.append(["Income Statement"])
        ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
        ws.append([])
        ws.append(["Account", "Amount"])

        total_income = decimal.Decimal("0")
        total_expense = decimal.Decimal("0")

        ws.append(["--- INCOME ---", ""])
        for num, a in data.items():
            if a["group"] == "Income":
                amt = a["credit"]
                total_income += amt
                ws.append([a["name"], float(amt)])

        # Total Income row
        ws.append([])
        ws.append(["Total Income", float(total_income)])

        ws.append([])
        ws.append(["--- EXPENSES ---", ""])
        ws.append([])
        ws.append(["Total Expenses", float(total_expense)])
        for num, a in data.items():
            if a["group"] == "Expenses":
                amt = a["debit"]
                total_expense += amt
                ws.append([a["name"], float(amt)])

        net = total_income - total_expense
        ws.append([])
        ws.append(["Net Income", float(net)])

        wb.save(path)
        messagebox.showinfo("Exported", f"Income Statement exported to:\n{path}")
