import uuid
from datetime import datetime
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

from widgets.date_picker import DateEntry
from db import (
    bootstrap_from_json,
    get_all_transactions,
    get_accounts_pairs,
    next_transaction_id,
    upsert_transaction,
    delete_transaction_by_id,
    delete_all_transactions,
)

# ======================================================
#   DEFAULT COA (fallback)
# ======================================================
DEFAULT_ACCOUNTS = [
    ("101", "Cash"),
    ("106", "Accounts Receivable"),
    ("124", "Supplies"),
    ("128", "Prepaid Rent"),
    ("167", "Equipment"),
    ("201", "Accounts Payable"),
    ("212", "Salaries Payable"),
    ("230", "Unearned Revenue"),
    ("301", "Owner's Capital"),
    ("302", "Owner's Drawings"),
    ("401", "Service Revenue"),
    ("502", "Salaries Expense"),
    ("503", "Supplies Expense"),
    ("506", "Cost of Goods Sold"),
    ("505", "Utilities Expense"),
    ("504", "Depreciation Expense"),
    ("501", "Rent Expense"),
]

# ======================================================
#   MAIN CLASS
# ======================================================
class TransactionPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        # Ensure SQLite DB exists and legacy JSON (if any) is imported once.
        bootstrap_from_json()

        # LOAD ACCOUNTS
        pairs = get_accounts_pairs()
        self.accounts = pairs if pairs else DEFAULT_ACCOUNTS[:]

        # ======================================================
        #   TITLE
        # ======================================================
        title = ctk.CTkLabel(self, text="Transactions",
                             font=("Segoe UI", 20, "bold"),
                             text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        # ======================================================
        #   FORM AREA
        # ======================================================
        top_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        top_frame.pack(fill="x", padx=18, pady=(0, 12))

        form = ctk.CTkFrame(top_frame, fg_color="transparent")
        form.pack(fill="x", padx=18, pady=12)

        # --- LEFT ---
        left = ctk.CTkFrame(form, fg_color="transparent")
        left.grid(row=0, column=0, sticky="nw", padx=(0, 30))
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Date (YYYY-MM-DD)",
                     text_color="#7fcaff").grid(row=0, column=0, sticky="w")
        self.date_entry = DateEntry(left, width=220, placeholder_text="YYYY-MM-DD")
        # stretch horizontally so it lines up nicely with Description entry
        self.date_entry.grid(row=1, column=0, pady=(6, 14), sticky="we")

        ctk.CTkLabel(left, text="Description",
                     text_color="#7fcaff").grid(row=2, column=0, sticky="w")
        self.desc_entry = ctk.CTkEntry(left, width=300,
                                       placeholder_text="Description")
        # also stretch horizontally to align with date field
        self.desc_entry.grid(row=3, column=0, pady=(6, 14), sticky="we")

        check = ctk.CTkFrame(left, fg_color="transparent")
        check.grid(row=4, column=0, pady=(2, 6), sticky="w")

        self.var_adjust = tk.IntVar()
        self.var_sched = tk.IntVar()

        ctk.CTkCheckBox(check, text="Adjusting Entry",
                        variable=self.var_adjust).grid(row=0, column=0)
        ctk.CTkCheckBox(check, text="Schedule Reversal",
                        variable=self.var_sched,
                        command=self.toggle_reversal).grid(row=0, column=1, padx=15)

        self.reversal_entry = DateEntry(check, width=140, placeholder_text="YYYY-MM-DD")
        self.reversal_entry.configure(state="disabled")
        self.reversal_entry.grid(row=0, column=2, padx=12)

        # --- MIDDLE ---
        mid = ctk.CTkFrame(form, fg_color="transparent")
        mid.grid(row=0, column=1, sticky="nw", padx=(0, 40))

        ctk.CTkLabel(mid, text="Credit Account",
                     text_color="#7fcaff").grid(row=0, column=0, sticky="w")
        self.credit_var = tk.StringVar()
        self.credit_dd = ctk.CTkComboBox(
            mid, width=300, values=self.build_acc_list(),
            variable=self.credit_var
        )
        self.credit_dd.grid(row=1, column=0, pady=(6, 14))

        ctk.CTkLabel(mid, text="Debit Account",
                     text_color="#7fcaff").grid(row=2, column=0, sticky="w")
        self.debit_var = tk.StringVar()
        self.debit_dd = ctk.CTkComboBox(
            mid, width=300, values=self.build_acc_list(),
            variable=self.debit_var
        )
        self.debit_dd.grid(row=3, column=0, pady=(6, 14))

        # --- RIGHT ---
        right = ctk.CTkFrame(form, fg_color="transparent")
        right.grid(row=0, column=2, sticky="ne")

        ctk.CTkLabel(right, text="Amount (Credit)",
                     text_color="#7fcaff").grid(row=0, column=0, sticky="w")
        self.credit_amt = ctk.CTkEntry(right, width=200,
                                       placeholder_text="Amount")
        self.credit_amt.grid(row=1, column=0, pady=(6, 14))

        self.btn_post = ctk.CTkButton(
            right, text="Record & Post",
            fg_color="#00c8ff", hover_color="#00a4cc",
            command=self.post_transaction
        )
        self.btn_post.grid(row=1, column=1, padx=(12, 0))

        ctk.CTkLabel(right, text="Amount (Debit)",
                     text_color="#7fcaff").grid(row=2, column=0, sticky="w")
        self.debit_amt = ctk.CTkEntry(right, width=200,
                                      placeholder_text="Amount")
        self.debit_amt.grid(row=3, column=0, pady=(6, 14))

        btn_box = ctk.CTkFrame(right, fg_color="transparent")
        btn_box.grid(row=3, column=1, padx=(12, 0))

        self.btn_draft = ctk.CTkButton(
            btn_box, text="Save Draft", fg_color="#4f5b66",
            command=self.save_draft
        )
        self.btn_draft.pack(pady=(0, 6))

        self.btn_clear = ctk.CTkButton(
            btn_box, text="Clear", fg_color="#4f5b66",
            command=self.clear_form
        )
        self.btn_clear.pack()

        # DIVIDER
        ttk.Separator(self).pack(fill="x", padx=18, pady=(6, 6))

        # ======================================================
        #   TABLE
        # ======================================================
        table = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        table.pack(fill="both", expand=True, padx=18)

        cols = ("id", "date", "desc", "debit", "credit", "amount")
        self.tree = ttk.Treeview(table, columns=cols, show="headings")

        for col, text in zip(cols,
                             ["ID", "DATE", "DESCRIPTION", "DEBIT", "CREDIT", "AMOUNT"]):
            self.tree.heading(col, text=text)

        self.tree.column("id", width=60, anchor="center")
        self.tree.column("date", width=120)
        self.tree.column("desc", width=360)
        self.tree.column("debit", width=160)
        self.tree.column("credit", width=160)
        self.tree.column("amount", width=120, anchor="e")

        # Only vertical scrollbar is needed; remove horizontal for a cleaner UI
        vsb = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=vsb.set)

        self.tree.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        vsb.pack(side="right", fill="y")

        # ======================================================
        #   DELETE ROWS
        # ======================================================
        del_frame = ctk.CTkFrame(self, fg_color="transparent")
        del_frame.pack(fill="x", pady=(4, 12))

        ctk.CTkButton(
            del_frame, text="Delete Selected",
            fg_color="#9b2a2a", hover_color="#7a1f1f",
            command=self.delete_selected
        ).pack(side="left", padx=20)

        ctk.CTkButton(
            del_frame, text="Delete All Records",
            fg_color="#b30000", hover_color="#8e0000",
            command=self.delete_all
        ).pack(side="left", padx=10)

        self.refresh()

    # ======================================================
    #   INTERNALS
    # ======================================================
    def build_acc_list(self):
        return [f"{code} - {name}" for code, name in self.accounts]

    def toggle_reversal(self):
        if self.var_sched.get():
            self.reversal_entry.configure(state="normal")
        else:
            self.reversal_entry.configure(state="disabled")
            self.reversal_entry.delete(0, "end")

    def clear_form(self):
        self.date_entry.delete(0, "end")
        self.desc_entry.delete(0, "end")
        self.credit_dd.set("")
        self.debit_dd.set("")
        self.credit_amt.delete(0, "end")
        self.debit_amt.delete(0, "end")
        self.var_adjust.set(0)
        self.var_sched.set(0)
        self.reversal_entry.configure(state="disabled")
        self.reversal_entry.delete(0, "end")

    # ======================================================
    #   INPUT READER
    # ======================================================
    def read_form(self):
        date = self.date_entry.get().strip()
        desc = self.desc_entry.get().strip()
        credit = self.credit_dd.get().strip()
        debit = self.debit_dd.get().strip()
        camt = self.credit_amt.get().strip()
        damt = self.debit_amt.get().strip()

        if not all([date, desc, credit, debit, camt, damt]):
            messagebox.showerror("Missing", "All fields are required.")
            return None

        try:
            datetime.strptime(date, "%Y-%m-%d")
        except:
            messagebox.showerror("Invalid", "Date format must be YYYY-MM-DD.")
            return None

        if self.var_sched.get():
            rev = self.reversal_entry.get().strip()
            try:
                datetime.strptime(rev, "%Y-%m-%d")
            except:
                messagebox.showerror("Invalid", "Reversal date invalid.")
                return None
        else:
            rev = ""

        try:
            float(camt); float(damt)
        except:
            messagebox.showerror("Error", "Amounts must be numeric.")
            return None

        def parse(x):
            parts = x.split(" - ", 1)
            return parts[0], parts[1]

        ccode, cname = parse(credit)
        dcode, dname = parse(debit)

        return {
            "id": next_transaction_id(),
            "date": date,
            "description": desc,
            "debit_acc_code": dcode,
            "debit_acc_name": dname,
            "credit_acc_code": ccode,
            "credit_acc_name": cname,
            "debit_amt": damt,
            "credit_amt": camt,
            "adjusting": self.var_adjust.get(),
            "scheduled_reversal": self.var_sched.get(),
            "reversal_date": rev,
            "status": "draft",
            "created_at": datetime.now().isoformat()
        }

    # ======================================================
    #   SAVE / POST TRANSACTION
    # ======================================================
    def save_draft(self):
        data = self.read_form()
        if not data:
            return

        data["status"] = "draft"
        upsert_transaction(data)
        self.refresh()
        messagebox.showinfo("Saved", "Draft saved successfully.")

    def post_transaction(self):
        data = self.read_form()
        if not data:
            return

        if float(data["credit_amt"]) != float(data["debit_amt"]):
            messagebox.showerror("Error", "Debit and Credit must be equal.")
            return

        data["status"] = "posted"
        upsert_transaction(data)
        self.refresh()
        messagebox.showinfo("Posted", "Transaction posted successfully.")

    # ======================================================
    #   TABLE OPS
    # ======================================================
    def refresh(self):
        for i in self.tree.get_children():
            self.tree.delete(i)

        for row in get_all_transactions():
            amt = f"{float(row['debit_amt']):,.2f}"
            self.tree.insert(
                "",
                "end",
                values=(
                    row["id"],
                    row["date"],
                    row["description"],
                    f"{row['debit_acc_code']} - {row['debit_acc_name']}",
                    f"{row['credit_acc_code']} - {row['credit_acc_name']}",
                    amt
                )
            )

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("None", "No row selected.")
            return

        rid = self.tree.item(sel[0], "values")[0]
        delete_transaction_by_id(rid)
        self.refresh()
        messagebox.showinfo("Deleted", "Record deleted.")

    def delete_all(self):
        if not messagebox.askyesno("Confirm", "Delete ALL records?"):
            return

        delete_all_transactions()
        self.refresh()
        messagebox.showinfo("Cleared", "All transactions removed.")
