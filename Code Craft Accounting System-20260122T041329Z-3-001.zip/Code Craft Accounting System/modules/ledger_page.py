# ============================================================
#   LEDGER PAGE — STRICT MODE (NEW COA FORMAT ONLY)
#   COA FORMAT EXPECTED:
#   {
#       "accounts": [
#           {"number": 101, "name": "Cash", "group": "Asset"},
#           ...
#       ]
#   }
# ============================================================

from datetime import datetime
import decimal
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import customtkinter as ctk

from db import bootstrap_from_json, get_all_accounts, get_all_transactions


# ===========================
# Decimal safe helper
# ===========================
def to_decimal(x):
    try:
        return decimal.Decimal(str(x))
    except:
        return decimal.Decimal("0.00")


# ===========================
# LEDGER PAGE CLASS
# ===========================
class LedgerPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        # Ensure DB exists and legacy JSON is imported once.
        bootstrap_from_json()

        # Load data from SQLite
        self.coa = self.load_coa_strict()

        # Title
        title = ctk.CTkLabel(self, text="Ledger",
                             font=("Segoe UI", 20, "bold"),
                             text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        content = ctk.CTkFrame(self, fg_color="transparent")
        content.pack(fill="both", expand=True, padx=18, pady=(0, 18))

        # ===========================
        # Left panel: accounts list
        # ===========================
        left_panel = ctk.CTkFrame(content, width=300, fg_color="#07121a", corner_radius=8)
        left_panel.pack(side="left", fill="y", padx=(0, 12), pady=6)

        ctk.CTkLabel(left_panel, text="Accounts", font=("Segoe UI", 14, "bold"),
                     text_color="#00a8e6").pack(anchor="nw", pady=(12, 6), padx=12)

        self.account_listbox = tk.Listbox(
            left_panel,
            bd=0,
            highlightthickness=0,
            activestyle="none",
            fg="#dceffb",
            bg="#07121a",
            selectbackground="#03303f",
            selectforeground="#fff",
            font=("Segoe UI", 10),
        )
        self.account_listbox.pack(fill="both", expand=True, padx=10, pady=10)
        self.account_listbox.bind("<<ListboxSelect>>", self.on_account_select)

        self.index_to_account = {}
        self.populate_account_list()

        # ===========================
        # Right panel: ledger
        # ===========================
        right_panel = ctk.CTkFrame(content, fg_color="#07121a", corner_radius=8)
        right_panel.pack(side="right", fill="both", expand=True, padx=(12, 0), pady=6)

        # Header
        header = ctk.CTkFrame(right_panel, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(12, 6))

        self.current_account_label = ctk.CTkLabel(
            header, text="Select an account",
            font=("Segoe UI", 15, "bold"),
            text_color="#00c8ff"
        )
        self.current_account_label.pack(side="left")

        # Export buttons
        btn_frame = ctk.CTkFrame(header, fg_color="transparent")
        btn_frame.pack(side="right")

        ctk.CTkButton(btn_frame, text="Export Account",
                      fg_color="#00c8ff", height=32,
                      command=self.export_account).pack(side="left", padx=(8, 6))

        ctk.CTkButton(btn_frame, text="Export All",
                      fg_color="#00c8ff", height=32,
                      command=self.export_all).pack(side="left")

        # Ledger table
        cols = ("date", "particulars", "postref", "debit", "credit", "balance")
        table_frame = tk.Frame(right_panel, bg="#07121a")
        table_frame.pack(fill="both", expand=True, padx=12, pady=(6, 12))

        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        for col in cols:
            self.tree.heading(col, text=col.capitalize())

        self.tree.column("date", width=100, anchor="center")
        self.tree.column("particulars", width=400)
        self.tree.column("postref", width=80, anchor="center")
        self.tree.column("debit", width=120, anchor="e")
        self.tree.column("credit", width=120, anchor="e")
        self.tree.column("balance", width=120, anchor="e")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        # Horizontal scrollbar removed; ledger columns are sized to fit typical widths.
        self.tree.configure(yscroll=vsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")

        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        # auto-select first account that actually has transactions (if any)
        self.auto_select_first_with_transactions()


    # ============================================================
    # STRICT COA LOADER (YOUR NEW FORMAT ONLY)
    # ============================================================
    def load_coa_strict(self):
        # normalised list from SQLite: [{number,name,group},...]
        data = get_all_accounts()
        if not data:
            messagebox.showerror("COA Missing", "No accounts found in database.")
            return {"Asset": [], "Liability": [], "Equity": [], "Income": [], "Expenses": []}

        grouped = {"Asset": [], "Liability": [], "Equity": [], "Income": [], "Expenses": []}

        for acct in data:
            group = str(acct.get("group", "")).title()
            if group in grouped:
                grouped[group].append(acct)

        return grouped


    # ============================================================
    # POPULATE ACCOUNT LIST
    # ============================================================
    def populate_account_list(self):
        self.account_listbox.delete(0, tk.END)
        self.index_to_account = {}
        idx = 0

        # Special "All Accounts" option at the very top
        self.account_listbox.insert(tk.END, "All Accounts (all transactions)")
        self.index_to_account[idx] = ("__ALL__", "All Accounts", "ALL")
        idx += 1

        for group in ["Asset", "Liability", "Equity", "Income", "Expenses"]:
            accounts = self.coa.get(group, [])
            if not accounts:
                continue

            self.account_listbox.insert(tk.END, f"--- {group.upper()} ---")
            idx += 1

            for acct in accounts:
                num = acct["number"]
                name = acct["name"]
                display = f"{num} - {name}"
                self.account_listbox.insert(tk.END, f"  {display}")
                self.index_to_account[idx] = (num, name, group)
                idx += 1


    # ============================================================
    # AUTO SELECT FIRST ACCOUNT WITH TRANSACTIONS
    # ============================================================
    def auto_select_first_with_transactions(self):
        """
        When opening the Ledger page, automatically select the first account
        that actually has at least one transaction, so the user immediately
        sees data without manually hunting for the right account.
        """
        # Prefer the special "All Accounts" view if it has any transactions.
        # Its key is always ("__ALL__", "All Accounts", "ALL").
        for idx, (code, name, group) in self.index_to_account.items():
            if code == "__ALL__" and group == "ALL":
                rows = self.build_all_ledger_rows()
                if rows:
                    self.account_listbox.selection_clear(0, tk.END)
                    self.account_listbox.selection_set(idx)
                    self.on_account_select()
                    return

        # Otherwise check each real account entry in order
        for idx, (code, name, group) in self.index_to_account.items():
            if code == "__ALL__" and group == "ALL":
                continue
            rows = self.build_ledger_rows(code, group)
            if rows:
                self.account_listbox.selection_clear(0, tk.END)
                self.account_listbox.selection_set(idx)
                self.on_account_select()
                return

        # Fallback: if no account has any transactions yet, just select the
        # first real account so the UI isn't empty/confusing.
        for i in range(self.account_listbox.size()):
            if i in self.index_to_account:
                self.account_listbox.selection_set(i)
                self.on_account_select()
                break


    # ============================================================
    # ACCOUNT SELECTED → BUILD LEDGER
    # ============================================================
    def on_account_select(self, event=None):
        sel = self.account_listbox.curselection()
        if not sel:
            return

        idx = sel[0]
        if idx not in self.index_to_account:
            return

        code, name, group = self.index_to_account[idx]

        # Handle special "All Accounts" view
        if code == "__ALL__" and group == "ALL":
            self.current_account_label.configure(text="All Accounts (all transactions)")
            rows = self.build_all_ledger_rows()
        else:
            self.current_account_label.configure(text=f"{code} - {name}")
            rows = self.build_ledger_rows(code, group)

        self.render_ledger(rows)


    # ============================================================
    # LEDGER BUILDING LOGIC
    # ============================================================
    def build_ledger_rows(self, code, group):
        debit_normal = group in ("Asset", "Expenses")
        running = decimal.Decimal("0.00")
        rows = []

        # Always pull the latest transactions from the DB so the ledger
        # reflects new entries immediately, without needing manual tricks.
        txs = sorted(get_all_transactions(), key=lambda t: t.get("date", ""))

        for tx in txs:
            debit_code = str(tx.get("debit_acc_code"))
            credit_code = str(tx.get("credit_acc_code"))

            da = to_decimal(tx.get("debit_amt", "0"))
            ca = to_decimal(tx.get("credit_amt", "0"))

            # If DEBIT
            if debit_code == str(code):
                running += da if debit_normal else -da
                rows.append({
                    "date": tx["date"],
                    "particulars": tx["description"],
                    "postref": tx["id"],
                    "debit": da,
                    "credit": decimal.Decimal("0"),
                    "balance": running
                })

            # If CREDIT
            if credit_code == str(code):
                running += -ca if debit_normal else ca
                rows.append({
                    "date": tx["date"],
                    "particulars": tx["description"],
                    "postref": tx["id"],
                    "debit": decimal.Decimal("0"),
                    "credit": ca,
                    "balance": running
                })

        return rows

    def build_all_ledger_rows(self):
        """
        Build a simple, chronological list of ALL posted and draft transactions,
        regardless of account. This gives a quick general-ledger style view.
        """
        rows = []
        txs = sorted(get_all_transactions(), key=lambda t: t.get("date", ""))

        for tx in txs:
            da = to_decimal(tx.get("debit_amt", "0"))
            ca = to_decimal(tx.get("credit_amt", "0"))

            rows.append({
                "date": tx.get("date", ""),
                "particulars": tx.get("description", ""),
                "postref": tx.get("id", ""),
                "debit": da,
                "credit": ca,
                # For the all-accounts view we skip a running balance per account.
                "balance": ""
            })

        return rows


    # ============================================================
    # RENDER LEDGER ROWS
    # ============================================================
    def render_ledger(self, rows):
        for i in self.tree.get_children():
            self.tree.delete(i)

        for r in rows:
            bal = r["balance"]
            bal_str = "" if bal == "" else f"{bal:,}"
            self.tree.insert("", "end", values=(
                r["date"],
                r["particulars"],
                r["postref"],
                f"{r['debit']:,}" if r["debit"] != 0 else "",
                f"{r['credit']:,}" if r["credit"] != 0 else "",
                bal_str
            ))


    # ============================================================
    # EXPORT FUNCTIONS
    # ============================================================
    def export_account(self):
        messagebox.showinfo("Info", "Export coming next (working).")

    def export_all(self):
        messagebox.showinfo("Info", "Export all coming next (working).")
