# modules/trial_balance_page.py
"""
Trial Balance Page (Unadjusted) - READY TO USE

Expects:
- data/chart_of_accounts.json with format:
  { "accounts": [ {"number": 101, "name": "Cash", "group": "Asset"}, ... ] }

- data/transactions.json containing list of transaction dicts
  Transactions must have "status": "posted" to be counted
"""

import decimal
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import customtkinter as ctk

from db import bootstrap_from_json, get_all_accounts, get_posted_transactions

# Decimal helper
def to_decimal(x):
    try:
        return decimal.Decimal(str(x))
    except Exception:
        return decimal.Decimal("0.00")


class TrialBalancePage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="#0b1628")

        # Ensure DB exists and legacy JSON is imported once.
        bootstrap_from_json()

        # Header
        title = ctk.CTkLabel(self, text="Trial Balance (Unadjusted)",
                             font=("Segoe UI", 20, "bold"),
                             text_color="#00c8ff")
        title.pack(anchor="nw", padx=20, pady=(18, 8))

        # Controls
        ctrl = ctk.CTkFrame(self, fg_color="transparent")
        ctrl.pack(fill="x", padx=18, pady=(0, 8))

        self.btn_refresh = ctk.CTkButton(ctrl, text="Refresh", width=120, command=self.refresh)
        self.btn_refresh.pack(side="left", padx=(0, 8))

        self.btn_export = ctk.CTkButton(ctrl, text="Export to Excel", width=160, fg_color="#00c8ff", command=self.export_xlsx)
        self.btn_export.pack(side="left", padx=(0, 8))

        self.status_label = ctk.CTkLabel(ctrl, text="", text_color="#7fcaff", font=("Segoe UI", 12, "bold"))
        self.status_label.pack(side="right")

        # Table frame
        table_frame = ctk.CTkFrame(self, fg_color="#07121a", corner_radius=8)
        table_frame.pack(fill="both", expand=True, padx=18, pady=(6, 18))
        # Use grid inside the table_frame so scrollbars line up nicely
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        cols = ("acct_no", "acct_name", "debit", "credit")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        self.tree.heading("acct_no", text="Account No")
        self.tree.heading("acct_name", text="Account Name")
        self.tree.heading("debit", text="Debit")
        self.tree.heading("credit", text="Credit")

        self.tree.column("acct_no", width=100, anchor="center")
        self.tree.column("acct_name", width=420)
        self.tree.column("debit", width=140, anchor="e")
        self.tree.column("credit", width=140, anchor="e")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        # Horizontal scrollbar removed; 4 columns fit comfortably in the frame.
        self.tree.configure(yscroll=vsb.set)

        # Place tree and scrollbar; vertical bar hugs the right edge.
        self.tree.grid(row=0, column=0, sticky="nsew", padx=(10, 0), pady=10)
        vsb.grid(row=0, column=1, sticky="ns", pady=10)

        # Totals footer
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=18, pady=(0, 14))

        self.total_debit_label = ctk.CTkLabel(footer, text="Total Debit: 0.00", font=("Segoe UI", 12, "bold"), text_color="#7fcaff")
        self.total_debit_label.pack(side="left", padx=(4, 12))

        self.total_credit_label = ctk.CTkLabel(footer, text="Total Credit: 0.00", font=("Segoe UI", 12, "bold"), text_color="#7fcaff")
        self.total_credit_label.pack(side="left", padx=(4, 12))

        # Internal caches
        self.coa_accounts = []
        self.posted_transactions = []

        # Initial render
        self.refresh(silent=True)

    # -------------------------
    # Data loaders
    # -------------------------
    def _load_coa(self):
        """Load COA from SQLite and normalise to list of dicts."""
        return get_all_accounts()

    def _load_transactions(self):
        """Load posted transactions only from SQLite."""
        return get_posted_transactions()

    # -------------------------
    # Compute trial balance
    # -------------------------
    def compute_trial_balance(self):
        self.coa_accounts = self._load_coa()
        self.posted_transactions = self._load_transactions()

        acct_map = {}
        for a in self.coa_accounts:
            num = a["number"]
            acct_map[num] = {
                "number": num,
                "name": a["name"],
                "group": a["group"].strip().title(),
                "debit_total": decimal.Decimal("0.00"),
                "credit_total": decimal.Decimal("0.00")
            }

        for t in self.posted_transactions:
            d_code = str(t.get("debit_acc_code", "")).strip()
            c_code = str(t.get("credit_acc_code", "")).strip()
            try:
                da = to_decimal(t.get("debit_amt", 0))
            except Exception:
                da = decimal.Decimal("0.00")
            try:
                ca = to_decimal(t.get("credit_amt", 0))
            except Exception:
                ca = decimal.Decimal("0.00")

            if d_code in acct_map:
                acct_map[d_code]["debit_total"] += da
            if c_code in acct_map:
                acct_map[c_code]["credit_total"] += ca

        group_order = ["Asset", "Liability", "Equity", "Income", "Expenses"]
        rows = []
        total_debit = decimal.Decimal("0.00")
        total_credit = decimal.Decimal("0.00")

        for grp in group_order:
            for acct in acct_map.values():
                if acct["group"].lower() == grp.lower():
                    debit = acct["debit_total"]
                    credit = acct["credit_total"]
                    rows.append((acct["number"], acct["name"], debit, credit))
                    total_debit += debit
                    total_credit += credit

        # uncategorized
        for acct in acct_map.values():
            if acct["group"] and acct["group"].title() in group_order:
                continue
            rows.append((acct["number"], acct["name"], acct["debit_total"], acct["credit_total"]))
            total_debit += acct["debit_total"]
            total_credit += acct["credit_total"]

        return rows, total_debit, total_credit

    # -------------------------
    # Render
    # -------------------------
    def render(self):
        for r in self.tree.get_children():
            self.tree.delete(r)

        rows, total_debit, total_credit = self.compute_trial_balance()

        for acct_no, acct_name, dr, cr in rows:
            dr_str = f"{dr:,.2f}" if dr != 0 else ""
            cr_str = f"{cr:,.2f}" if cr != 0 else ""
            self.tree.insert("", "end", values=(acct_no, acct_name, dr_str, cr_str))

        self.total_debit_label.configure(text=f"Total Debit: {total_debit:,.2f}")
        self.total_credit_label.configure(text=f"Total Credit: {total_credit:,.2f}")

        if total_debit == total_credit:
            self.status_label.configure(text="Balanced ✔", text_color="#7fffb3")
        else:
            diff = total_debit - total_credit
            self.status_label.configure(text=f"Not Balanced — Diff: {diff:,.2f}", text_color="#ff8080")

    # -------------------------
    # Refresh (silent optional)
    # -------------------------
    def refresh(self, silent=False):
        try:
            self.render()
            if not silent:
                messagebox.showinfo("Refreshed", "Trial Balance refreshed.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not refresh Trial Balance:\n{e}")

    # -------------------------
    # Export to Excel
    # -------------------------
    def export_xlsx(self):
        try:
            from openpyxl import Workbook
            from openpyxl.utils import get_column_letter
            from openpyxl.styles import Font, Alignment
        except Exception:
            messagebox.showerror("Missing dependency", "openpyxl is required to export to Excel. Install: pip install openpyxl")
            return

        rows, total_debit, total_credit = self.compute_trial_balance()

        default_name = "Trial_Balance_Unadjusted.xlsx"
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile=default_name,
                                            filetypes=[("Excel Workbook", "*.xlsx")])
        if not path:
            return

        wb = Workbook()
        ws = wb.active
        ws.title = "Trial Balance"

        ws.append(["Trial Balance (Unadjusted)"])
        ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
        ws.append([])
        ws.append(["Account No", "Account Name", "Debit", "Credit"])

        bold = Font(bold=True)
        for col in range(1, 5):
            ws.cell(row=4, column=col).font = bold
            ws.cell(row=4, column=col).alignment = Alignment(horizontal="center")

        for acct_no, acct_name, dr, cr in rows:
            ws.append([acct_no, acct_name, float(dr), float(cr)])

        ws.append([])
        ws.append(["", "TOTALS", float(total_debit), float(total_credit)])

        widths = [12, 50, 18, 18]
        for i, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w

        wb.save(path)
        messagebox.showinfo("Exported", f"Trial Balance exported to:\n{path}")
