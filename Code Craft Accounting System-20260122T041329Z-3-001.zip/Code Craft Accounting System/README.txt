CodeCraft v5 Light Fixed - full UI included. Run python main.py
Requirements: customtkinter, pillow
