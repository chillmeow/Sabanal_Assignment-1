import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
from PIL import Image

# Import all your module pages
from modules.transaction_page import TransactionPage
from modules.journal_page import JournalPage
from modules.ledger_page import LedgerPage
from modules.trial_balance_page import TrialBalancePage
from modules.adjustments_page import AdjustmentsPage
from modules.income_statement_page import IncomeStatementPage
from modules.closing_page import ClosingPage
from modules.post_closing_page import PostClosingPage
from modules.export_page import ExportPage

# ============================
#   GLOBAL UI SETTINGS
# ============================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

SIDEBAR_BG = "#06101f"
BTN_BG = "#0a1a2e"
BTN_HOVER = "#003b63"
TEXT_COLOR = "#d9eaff"
TITLE_COLOR = "#00c8ff"


# ============================
#        MAIN APP
# ============================
class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("CodeCraft Custom PC Builds")
        # Ensure a minimum usable size if/when the user exits fullscreen
        self.minsize(1100, 700)
        self.configure(fg_color="#0b1628")

        self.current_page = None

        # ============================
        #   GLOBAL TREEVIEW STYLING
        # ============================
        self._configure_treeview_style()

        # ============================
        #   FULLSCREEN BEHAVIOR
        # ============================
        self._is_fullscreen = True
        # Start in true fullscreen mode on launch
        self.attributes("-fullscreen", True)
        # Allow user to toggle fullscreen with F11 or exit with Esc
        self.bind("<F11>", self.toggle_fullscreen)
        self.bind("<Escape>", self.exit_fullscreen)

        self.create_sidebar()
        self.create_content_area()

        # Default Page
        self.show_page(TransactionPage)

    def _configure_treeview_style(self):
        """Configure a dark, readable style for all ttk.Treeview widgets."""
        style = ttk.Style(self)
        # Use default/base theme as a starting point
        try:
            style.theme_use("default")
        except Exception:
            pass

        # General row styling
        style.configure(
            "Treeview",
            background="#07121a",
            fieldbackground="#07121a",
            foreground="#e2f0ff",
            rowheight=26,
            font=("Segoe UI", 11),
            borderwidth=0
        )

        # Header styling
        style.configure(
            "Treeview.Heading",
            background="#0d2138",
            foreground="#ffffff",
            font=("Segoe UI Semibold", 11),
            relief="flat"
        )
        style.map(
            "Treeview.Heading",
            background=[("active", "#12345b")]
        )

        # Selection/highlight colors
        style.map(
            "Treeview",
            background=[("selected", "#005b99")],
            foreground=[("selected", "#ffffff")]
        )

    def toggle_fullscreen(self, event=None):
        """Toggle between fullscreen and windowed mode."""
        self._is_fullscreen = not self._is_fullscreen
        self.attributes("-fullscreen", self._is_fullscreen)

    def exit_fullscreen(self, event=None):
        """Exit fullscreen but keep the window at a good size."""
        self._is_fullscreen = False
        self.attributes("-fullscreen", False)
        # Keep a reasonable window size after exiting fullscreen
        self.geometry("1400x800")

    # ============================
    #     SIDEBAR CREATION
    # ============================
    def create_sidebar(self):
        # Root sidebar frame
        self.sidebar = ctk.CTkFrame(self, width=240, fg_color=SIDEBAR_BG)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # --- Top: logo and title ---
        header = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        header.pack(side="top", fill="x", pady=(15, 10))

        ctk.CTkLabel(
            header, text="💠",
            font=("Segoe UI", 40),
            text_color=TITLE_COLOR
        ).pack(pady=(10, 5))

        ctk.CTkLabel(
            header,
            text="CodeCraft Accounting",
            font=("Segoe UI Semibold", 16),
            text_color=TITLE_COLOR
        ).pack(pady=(0, 10))

        # --- Middle: static menu (no sidebar scrollbar) ---
        # Use a simple frame so there is no scrollbar in the sidebar.
        # On very small window heights some buttons may move off-screen,
        # but at your normal/fullscreen size they will all be visible.
        menu_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        menu_frame.pack(side="top", fill="both", expand=True, padx=5, pady=(0, 5))

        # ICON LOADER
        def load_icon(filename):
            try:
                img = Image.open(f"assets/icons/{filename}").resize((24, 24))
                return ctk.CTkImage(light_image=img, dark_image=img, size=(24, 24))
            except Exception:
                return None

        # MENU CONFIG
        menu = [
            ("Transactions", TransactionPage, "transaction.jpg"),
            ("Journal", JournalPage, "journal.jpg"),
            ("Ledger", LedgerPage, "ledger.jpg"),
            ("Trial Balance", TrialBalancePage, "trial balance.jpg"),
            ("Adjustments", AdjustmentsPage, "adjustments.jpg"),
            ("Fin. Statements", IncomeStatementPage, "financial statements.jpg"),
            ("Closing", ClosingPage, "closing.jpg"),
            ("Post-Closing", PostClosingPage, "download (2).jpg"),
            ("Export", ExportPage, "export.png"),
        ]

        # BUILD SIDEBAR BUTTONS inside the scrollable frame
        for label, page, icon_file in menu:
            icon = load_icon(icon_file)

            button = ctk.CTkButton(
                master=menu_frame,
                text=f"   {label}",
                image=icon,
                compound="left",
                anchor="w",
                command=lambda p=page: self.show_page(p),
                height=45,
                fg_color=BTN_BG,
                hover_color=BTN_HOVER,
                text_color=TEXT_COLOR,
                corner_radius=10,
                font=("Segoe UI", 15)
            )
            button.pack(fill="x", padx=10, pady=4)

        # --- Bottom: Exit button, always visible at bottom of sidebar ---
        bottom_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        bottom_frame.pack(side="bottom", fill="x", pady=(5, 15))

        exit_button = ctk.CTkButton(
            master=bottom_frame,
            text="  Exit",
            command=self.destroy,
            height=40,
            fg_color="#b00020",      # red
            hover_color="#d32f2f",   # brighter red on hover
            text_color="white",
            corner_radius=10,
            font=("Segoe UI Semibold", 14)
        )
        exit_button.pack(fill="x", padx=15)

    # ============================
    #    MAIN CONTENT AREA
    # ============================
    def create_content_area(self):
        self.content = ctk.CTkFrame(self, fg_color="#0b1628")
        self.content.pack(side="right", fill="both", expand=True)

    # ============================
    #     PAGE SWITCHING
    # ============================
    def show_page(self, PageClass):
        if self.current_page is not None:
            self.current_page.destroy()

        self.current_page = PageClass(self.content)
        self.current_page.pack(fill="both", expand=True)


# ============================
#        RUN APPLICATION
# ============================
if __name__ == "__main__":
    app = App()
    app.mainloop()
