import os
import json
import sqlite3
from contextlib import contextmanager


DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DB_PATH = os.path.join(DATA_DIR, "accounting.db")

COA_JSON = os.path.join(DATA_DIR, "chart_of_accounts.json")
TRANS_JSON = os.path.join(DATA_DIR, "transactions.json")


def _ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


@contextmanager
def get_conn():
    """Context-managed SQLite connection with Row factory."""
    _ensure_data_dir()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """Create tables if they do not exist."""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS chart_of_accounts (
                number TEXT PRIMARY KEY,
                name   TEXT NOT NULL,
                grp    TEXT NOT NULL
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id                TEXT PRIMARY KEY,
                date              TEXT NOT NULL,
                description       TEXT NOT NULL,
                debit_acc_code    TEXT NOT NULL,
                debit_acc_name    TEXT NOT NULL,
                credit_acc_code   TEXT NOT NULL,
                credit_acc_name   TEXT NOT NULL,
                debit_amt         REAL NOT NULL,
                credit_amt        REAL NOT NULL,
                adjusting         INTEGER DEFAULT 0,
                scheduled_reversal INTEGER DEFAULT 0,
                reversal_date     TEXT,
                status            TEXT NOT NULL,
                created_at        TEXT,
                closing           INTEGER DEFAULT 0,
                closing_batch     TEXT
            )
            """
        )


def _import_coa_from_json_if_empty():
    """Populate chart_of_accounts from existing JSON on first run."""
    if not os.path.exists(COA_JSON):
        return
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM chart_of_accounts")
        if cur.fetchone()[0] > 0:
            return

        try:
            with open(COA_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return

        rows = []
        # Preferred format: {"accounts":[{number,name,group},...]}
        if isinstance(data, dict) and isinstance(data.get("accounts"), list):
            for a in data["accounts"]:
                if not isinstance(a, dict):
                    continue
                num = str(a.get("number", "")).strip()
                name = str(a.get("name", "")).strip()
                grp = str(a.get("group", "")).strip()
                if not num or not name:
                    continue
                rows.append((num, name, grp))
        elif isinstance(data, dict):
            # Categorised dict: {"ASSETS":[{code,name},...], ...}
            for cat, lst in data.items():
                if not isinstance(lst, list):
                    continue
                grp = str(cat).strip()
                for item in lst:
                    if isinstance(item, dict):
                        num = str(item.get("code", "")).strip()
                        name = str(item.get("name", "")).strip()
                    elif isinstance(item, (list, tuple)) and len(item) >= 2:
                        num = str(item[0]).strip()
                        name = str(item[1]).strip()
                    else:
                        continue
                    if not num or not name:
                        continue
                    rows.append((num, name, grp))
        elif isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    num = str(item.get("code", "") or item.get("number", "")).strip()
                    name = str(item.get("name", "")).strip()
                    grp = str(item.get("group", "")).strip()
                elif isinstance(item, (list, tuple)) and len(item) >= 2:
                    num = str(item[0]).strip()
                    name = str(item[1]).strip()
                    grp = ""
                else:
                    continue
                if not num or not name:
                    continue
                rows.append((num, name, grp))

        if rows:
            cur.executemany(
                "INSERT OR REPLACE INTO chart_of_accounts (number, name, grp) VALUES (?,?,?)",
                rows,
            )


def _import_transactions_from_json_if_empty():
    """Populate transactions table from existing JSON on first run."""
    if not os.path.exists(TRANS_JSON):
        return
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM transactions")
        if cur.fetchone()[0] > 0:
            return

        try:
            with open(TRANS_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return

        if not isinstance(data, list):
            return

        rows = []
        for t in data:
            if not isinstance(t, dict):
                continue
            tid = str(t.get("id", "")).strip()
            if not tid:
                continue
            rows.append(
                (
                    tid,
                    t.get("date", ""),
                    t.get("description", ""),
                    str(t.get("debit_acc_code", "")).strip(),
                    str(t.get("debit_acc_name", "")).strip(),
                    str(t.get("credit_acc_code", "")).strip(),
                    str(t.get("credit_acc_name", "")).strip(),
                    float(t.get("debit_amt", 0) or 0),
                    float(t.get("credit_amt", 0) or 0),
                    int(t.get("adjusting", 0) or 0),
                    int(t.get("scheduled_reversal", 0) or 0),
                    t.get("reversal_date", "") or "",
                    str(t.get("status", "draft")),
                    t.get("created_at", "") or "",
                    int(t.get("closing", 0) or 0),
                    t.get("_closing_batch", "") or "",
                )
            )

        if rows:
            cur.executemany(
                """
                INSERT OR REPLACE INTO transactions
                (id, date, description,
                 debit_acc_code, debit_acc_name,
                 credit_acc_code, credit_acc_name,
                 debit_amt, credit_amt,
                 adjusting, scheduled_reversal, reversal_date,
                 status, created_at, closing, closing_batch)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                rows,
            )


def bootstrap_from_json():
    """Public helper: ensure DB exists and import legacy JSON once."""
    init_db()
    _import_coa_from_json_if_empty()
    _import_transactions_from_json_if_empty()


# ---------------------------------------------------------------------------
# COA helpers
# ---------------------------------------------------------------------------

def get_all_accounts():
    """Return list of dicts: {number, name, group}."""
    init_db()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT number, name, grp FROM chart_of_accounts ORDER BY number")
        return [
            {"number": r["number"], "name": r["name"], "group": r["grp"]}
            for r in cur.fetchall()
        ]


def get_accounts_pairs():
    """Return list of (code, name) for combo boxes."""
    return [(a["number"], a["name"]) for a in get_all_accounts()]


# ---------------------------------------------------------------------------
# Transaction helpers
# ---------------------------------------------------------------------------

def get_all_transactions():
    """Return all transactions as list of dicts (JSON-compatible structure)."""
    init_db()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM transactions ORDER BY CAST(id AS INTEGER)")
        rows = cur.fetchall()

    out = []
    for r in rows:
        out.append(
            {
                "id": r["id"],
                "date": r["date"],
                "description": r["description"],
                "debit_acc_code": r["debit_acc_code"],
                "debit_acc_name": r["debit_acc_name"],
                "credit_acc_code": r["credit_acc_code"],
                "credit_acc_name": r["credit_acc_name"],
                "debit_amt": r["debit_amt"],
                "credit_amt": r["credit_amt"],
                "adjusting": r["adjusting"],
                "scheduled_reversal": r["scheduled_reversal"],
                "reversal_date": r["reversal_date"],
                "status": r["status"],
                "created_at": r["created_at"],
                "closing": r["closing"],
                "_closing_batch": r["closing_batch"],
            }
        )
    return out


def get_posted_transactions():
    """Return only posted transactions."""
    return [t for t in get_all_transactions() if str(t.get("status", "")).lower() == "posted"]


def get_adjusting_transactions():
    """Return transactions where adjusting == 1."""
    return [t for t in get_all_transactions() if int(t.get("adjusting", 0) or 0) == 1]


def next_transaction_id():
    """Generate next string id based on current max(id)."""
    init_db()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id FROM transactions")
        ids = []
        for (tid,) in cur.fetchall():
            try:
                ids.append(int(str(tid)))
            except Exception:
                continue
        return str(max(ids) + 1 if ids else 1)


def upsert_transaction(tx):
    """
    Insert or update a transaction.
    Expects tx dict with same keys as get_all_transactions.
    """
    init_db()
    if not tx.get("id"):
        tx["id"] = next_transaction_id()

    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            """
            INSERT OR REPLACE INTO transactions
            (id, date, description,
             debit_acc_code, debit_acc_name,
             credit_acc_code, credit_acc_name,
             debit_amt, credit_amt,
             adjusting, scheduled_reversal, reversal_date,
             status, created_at, closing, closing_batch)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                str(tx.get("id")),
                tx.get("date", ""),
                tx.get("description", ""),
                str(tx.get("debit_acc_code", "")).strip(),
                str(tx.get("debit_acc_name", "")).strip(),
                str(tx.get("credit_acc_code", "")).strip(),
                str(tx.get("credit_acc_name", "")).strip(),
                float(tx.get("debit_amt", 0) or 0),
                float(tx.get("credit_amt", 0) or 0),
                int(tx.get("adjusting", 0) or 0),
                int(tx.get("scheduled_reversal", 0) or 0),
                tx.get("reversal_date", "") or "",
                str(tx.get("status", "draft")),
                tx.get("created_at", "") or "",
                int(tx.get("closing", 0) or 0),
                tx.get("_closing_batch", "") or "",
            ),
        )
    return tx["id"]


def delete_transaction_by_id(tx_id: str):
    init_db()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM transactions WHERE id = ?", (str(tx_id),))


def delete_all_transactions():
    init_db()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM transactions")


def delete_transactions_by_closing_batch(batch_token: str):
    """Used by closing page for undo functionality."""
    init_db()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM transactions WHERE closing_batch = ?", (batch_token,))



